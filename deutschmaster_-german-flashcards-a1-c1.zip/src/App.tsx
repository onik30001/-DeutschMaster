import { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthProvider';
import { useAuth } from './context/AuthContext';
import { ContentProvider } from './context/ContentProvider';
import { useContent } from './context/ContentContext';
import { FlashcardComponent } from './components/Flashcard';
import { DictionaryView } from './components/DictionaryView';
import { QuizComponent } from './components/Quiz';
import { Payment } from './components/Payment';
import { AdminPanel } from './components/AdminPanel';
import { GrammarSection } from './components/GrammarSection';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Level, WordType } from './types';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  GraduationCap, 
  BookOpen, 
  Settings, 
  LogOut, 
  Layout, 
  Zap,
  Star,
  Bookmark as BookmarkIcon,
  Search,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Volume2,
  CreditCard,
  Lock
} from 'lucide-react';
import { auth, googleProvider, signInWithPopup, signOut } from './firebase';

const Dashboard = () => {
  const { user, progress, updateProgress, hasAccess } = useAuth();
  const { content } = useContent();
  const [view, setView] = useState<'learn' | 'quiz' | 'dashboard' | 'grammar' | 'favorites' | 'bookmarks' | 'admin' | 'payment'>('dashboard');
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [selectedWordType, setSelectedWordType] = useState<WordType>('Any');
  const [learnMode, setLearnMode] = useState<'flashcard' | 'dictionary'>('flashcard');
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    // Use a timeout to avoid synchronous state update in effect
    const timer = setTimeout(() => setCurrentCardIndex(0), 0);
    return () => clearTimeout(timer);
  }, [selectedWordType, progress?.level]);

  const levels: Level[] = ['A1', 'A2', 'B1', 'B2', 'C1'];
  const wordTypes: WordType[] = ['Any', 'Adjective', 'Adverb', 'Noun', 'Number', 'Verb', 'Grammar', 'Phrase'];

  const currentLevelContent = content[progress?.level || 'A1'] || { flashcards: [], quizzes: [] };
  
  const vocabQuizzes = (currentLevelContent.quizzes || []).filter(q => q.type === 'vocabulary');
  const grammarQuizzes = (currentLevelContent.quizzes || []).filter(q => q.type === 'grammar');

  const [quizType, setQuizType] = useState<'vocabulary' | 'grammar' | null>(null);

  const filteredFlashcards = (currentLevelContent.flashcards || []).filter(card => 
    selectedWordType === 'Any' || card.wordType === selectedWordType
  );

  const totalWordsInLevel = currentLevelContent.flashcards?.length || 0;
  const learnedWordsCount = progress?.favorites?.filter(id => 
    currentLevelContent.flashcards?.some(f => f.id === id)
  ).length || 0;
  
  const progressPercentage = totalWordsInLevel > 0 
    ? Math.round((learnedWordsCount / totalWordsInLevel) * 100) 
    : 0;

  const vocabInLevel = (currentLevelContent.flashcards || []).filter(f => f.type === 'vocabulary');
  const grammarInLevel = (currentLevelContent.flashcards || []).filter(f => f.type === 'grammar');
  
  const learnedVocabCount = progress?.favorites?.filter(id => 
    vocabInLevel.some(f => f.id === id)
  ).length || 0;
  
  const learnedGrammarCount = progress?.favorites?.filter(id => 
    grammarInLevel.some(f => f.id === id)
  ).length || 0;

  const isLevelUnlocked = hasAccess(progress?.level || 'A1');

  const vocabProgress = vocabInLevel.length > 0 ? Math.round((learnedVocabCount / vocabInLevel.length) * 100) : 0;
  const grammarProgress = grammarInLevel.length > 0 ? Math.round((learnedGrammarCount / grammarInLevel.length) * 100) : 0;

  const nextMilestone = Math.ceil(((progress?.xp || 0) + 1) / 500) * 500;
  const xpProgress = ((progress?.xp || 0) % 500) / 500 * 100;

  const getRank = (xp: number) => {
    if (xp < 500) return 'Novice';
    if (xp < 1500) return 'Apprentice';
    if (xp < 3000) return 'Scholar';
    if (xp < 6000) return 'Master';
    return 'Grandmaster';
  };

  const favoriteFlashcards = Object.values(content).flatMap(level => level.flashcards || []).filter(card => 
    progress?.favorites?.includes(card.id) || false
  );

  const bookmarkedFlashcards = Object.values(content).flatMap(level => level.flashcards || []).filter(card => 
    progress?.bookmarks?.includes(card.id) || false
  );

  const handleToggleFavorite = async (id: string) => {
    const favorites = progress?.favorites || [];
    const newFavorites = favorites.includes(id) 
      ? favorites.filter(f => f !== id)
      : [...favorites, id];
    await updateProgress({ favorites: newFavorites });
  };

  const handleToggleBookmark = async (id: string) => {
    const bookmarks = progress?.bookmarks || [];
    const newBookmarks = bookmarks.includes(id) 
      ? bookmarks.filter(b => b !== id)
      : [...bookmarks, id];
    await updateProgress({ bookmarks: newBookmarks });
  };

  const handleSpeak = async (text: string) => {
    try {
      const { generateSpeech, playAudio } = await import('./services/gemini');
      const audioData = await generateSpeech(text);
      if (audioData) {
        playAudio(audioData.data, audioData.mimeType || 'audio/mpeg');
      } else {
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'de-DE';
        window.speechSynthesis.speak(utterance);
      }
    } catch {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'de-DE';
      window.speechSynthesis.speak(utterance);
    }
  };

  return (
    <div className="min-h-screen bg-[#FDFDFD] flex flex-col lg:flex-row font-sans">
      {/* Mobile Header */}
      <header className="lg:hidden glass sticky top-0 z-50 p-4 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-zinc-900 p-1.5 rounded-lg shadow-lg shadow-zinc-900/20">
            <GraduationCap className="w-5 h-5 text-white" />
          </div>
          <h1 className="text-lg font-bold tracking-tight uppercase">DeutschMaster</h1>
        </div>
        <button 
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="p-2 text-zinc-900 bg-zinc-50 rounded-xl border border-zinc-100"
        >
          <Layout className="w-6 h-6" />
        </button>
      </header>

      {/* Sidebar */}
      <aside className={`
        fixed inset-0 z-[60] lg:relative lg:z-0 lg:w-80 bg-white border-r border-zinc-100 flex flex-col p-8 lg:sticky lg:top-0 lg:h-screen transition-all duration-500 ease-in-out
        ${isMobileMenuOpen ? 'translate-x-0 opacity-100' : '-translate-x-full lg:translate-x-0 opacity-0 lg:opacity-100'}
      `}>
        <div className="hidden lg:flex items-center gap-3 mb-12">
          <div className="bg-zinc-900 p-2.5 rounded-2xl shadow-xl shadow-zinc-900/20">
            <GraduationCap className="w-6 h-6 text-white" />
          </div>
          <h1 className="text-2xl font-bold tracking-tight uppercase">DeutschMaster</h1>
        </div>

        <nav className="flex-1 space-y-1.5 overflow-y-auto pr-2 custom-scrollbar">
          {([
            { id: 'dashboard', icon: Layout, label: 'Dashboard' },
            { id: 'learn', icon: BookOpen, label: 'Flashcards' },
            { id: 'grammar', icon: GraduationCap, label: 'Grammar' },
            { id: 'quiz', icon: Zap, label: 'Quizzes' },
            { id: 'payment', icon: CreditCard, label: 'Unlock Levels' },
            { id: 'favorites', icon: Star, label: 'Favorites' },
            { id: 'bookmarks', icon: BookmarkIcon, label: 'Bookmarks' }
          ] as const).map(item => (
            <button 
              key={item.id}
              onClick={() => { setView(item.id); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all duration-300 ${view === item.id ? 'bg-zinc-900 text-white shadow-2xl shadow-zinc-900/30 scale-[1.02]' : 'text-zinc-400 hover:bg-zinc-50 hover:text-zinc-600'}`}
            >
              <item.icon className={`w-5 h-5 ${view === item.id ? 'text-white' : 'text-zinc-300'}`} /> {item.label}
            </button>
          ))}
          
          {(progress?.role === 'admin' || user?.email === 'onik30001@gmail.com') && (
            <button 
              onClick={() => { setView('admin'); setIsMobileMenuOpen(false); }}
              className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold transition-all duration-300 ${view === 'admin' ? 'bg-zinc-900 text-white shadow-2xl shadow-zinc-900/30 scale-[1.02]' : 'text-zinc-400 hover:bg-zinc-50 hover:text-zinc-600'}`}
            >
              <Settings className={`w-5 h-5 ${view === 'admin' ? 'text-white' : 'text-zinc-300'}`} /> Admin Panel
            </button>
          )}
        </nav>

        <div className="pt-8 border-t border-zinc-100 mt-auto">
          <div className="flex items-center gap-4 px-4 mb-8">
            <div className="relative">
              <img src={user?.photoURL || ''} className="w-12 h-12 rounded-2xl border-2 border-white shadow-md object-cover" alt="Profile" />
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-white rounded-full shadow-sm" />
            </div>
            <div className="min-w-0">
              <p className="font-bold text-sm truncate text-zinc-900">{user?.displayName}</p>
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">{progress?.level} Mastery</p>
            </div>
          </div>
          <button 
            onClick={() => signOut(auth)}
            className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl font-bold text-rose-500 bg-rose-50/50 hover:bg-rose-50 transition-all duration-300 border border-rose-100/50"
          >
            <LogOut className="w-5 h-5" /> Sign Out
          </button>
        </div>
      </aside>

      {/* Overlay for mobile menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-zinc-900/20 backdrop-blur-md z-[55] lg:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Main Content */}
      <main className="flex-1 p-6 lg:p-12 overflow-y-auto custom-scrollbar">
        <AnimatePresence mode="wait">
          {view === 'dashboard' && (
            <motion.div 
              key="dashboard"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="space-y-12"
            >
              <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
                <div>
                  <h2 className="text-4xl font-bold tracking-tight uppercase mb-2">Guten Tag, {user?.displayName?.split(' ')[0]}!</h2>
                  <p className="text-zinc-400 font-bold uppercase tracking-[0.2em] text-xs">Your German learning odyssey continues.</p>
                </div>
                <div className="flex items-center gap-3 bg-zinc-100/50 p-2 rounded-2xl border border-zinc-200/50">
                  {levels.map(l => {
                    const unlocked = hasAccess(l);
                    return (
                      <button 
                        key={l}
                        onClick={() => {
                          if (unlocked) {
                            updateProgress({ level: l });
                          } else {
                            setView('payment');
                          }
                        }}
                        className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 ${progress?.level === l ? 'bg-zinc-900 text-white shadow-lg' : 'text-zinc-400 hover:text-zinc-600'}`}
                      >
                        {l}
                        {!unlocked && <Lock className="w-3 h-3" />}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="space-y-8">
                <div className="glass-dark rounded-[48px] p-10 text-white relative overflow-hidden group">
                  <div className="relative z-10 grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="space-y-8">
                      <div>
                        <span className="bg-white/10 px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking-widest mb-6 inline-block backdrop-blur-md border border-white/5">Mastery Path</span>
                        <h3 className="text-4xl font-bold tracking-tight mb-2 uppercase">Level {progress?.level}</h3>
                        <p className="text-zinc-400 text-sm leading-relaxed">You've mastered <span className="text-white font-bold">{learnedWordsCount}</span> of <span className="text-white font-bold">{totalWordsInLevel}</span> items. The path to fluency is paved with consistency.</p>
                      </div>

                      <div className="space-y-6">
                        <div className="space-y-3">
                          <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                            <span>Overall Mastery</span>
                            <span className="text-white">{progressPercentage}%</span>
                          </div>
                          <div className="h-3 bg-white/5 rounded-full overflow-hidden border border-white/5">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${progressPercentage}%` }}
                              transition={{ duration: 1, ease: "easeOut" }}
                              className="h-full bg-gradient-to-r from-white/80 to-white shadow-[0_0_20px_rgba(255,255,255,0.3)]"
                            />
                          </div>
                        </div>

                        <div className="space-y-3">
                          <div className="flex justify-between text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                            <span>XP to Milestone</span>
                            <span className="text-amber-400">{progress?.xp} / {nextMilestone} XP</span>
                          </div>
                          <div className="h-3 bg-white/5 rounded-full overflow-hidden border border-white/5">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${xpProgress}%` }}
                              transition={{ duration: 1, ease: "easeOut", delay: 0.2 }}
                              className="h-full bg-gradient-to-r from-amber-400 to-amber-300 shadow-[0_0_20px_rgba(251,191,36,0.3)]"
                            />
                          </div>
                        </div>
                      </div>

                      <button 
                        onClick={() => {
                          if (isLevelUnlocked) {
                            setView('learn');
                          } else {
                            setView('payment');
                          }
                        }}
                        className="bg-white text-zinc-900 px-10 py-5 rounded-[24px] font-bold uppercase tracking-widest text-xs hover:scale-[1.05] active:scale-[0.98] transition-all shadow-2xl shadow-white/10 flex items-center gap-3 group"
                      >
                        {isLevelUnlocked ? 'Continue Learning' : 'Unlock Level'} <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                      </button>
                    </div>

                    <div className="bg-white/5 rounded-[40px] p-8 backdrop-blur-xl border border-white/10 space-y-8 flex flex-col justify-center">
                      <h4 className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-500">Performance Analytics</h4>
                      
                      <div className="grid grid-cols-2 gap-8">
                        <div className="space-y-4">
                          <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Vocab Accuracy</p>
                          <div className="flex items-baseline gap-1">
                            <p className="text-4xl font-bold text-white">{progress?.quizScores?.vocabulary || 0}</p>
                            <span className="text-xs font-bold text-zinc-500">%</span>
                          </div>
                          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${progress?.quizScores?.vocabulary || 0}%` }}
                              className="h-full bg-indigo-400 shadow-[0_0_15px_rgba(129,140,248,0.5)]" 
                            />
                          </div>
                        </div>
                        <div className="space-y-4">
                          <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest">Grammar Accuracy</p>
                          <div className="flex items-baseline gap-1">
                            <p className="text-4xl font-bold text-white">{progress?.quizScores?.grammar || 0}</p>
                            <span className="text-xs font-bold text-zinc-500">%</span>
                          </div>
                          <div className="h-1.5 bg-white/5 rounded-full overflow-hidden">
                            <motion.div 
                              initial={{ width: 0 }}
                              animate={{ width: `${progress?.quizScores?.grammar || 0}%` }}
                              className="h-full bg-emerald-400 shadow-[0_0_15px_rgba(52,211,153,0.5)]" 
                            />
                          </div>
                        </div>
                      </div>

                      <div className="pt-8 border-t border-white/5 grid grid-cols-2 gap-8">
                        <div>
                          <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Vocab Mastery</p>
                          <p className="text-2xl font-bold text-white">{vocabProgress}%</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-widest mb-2">Grammar Mastery</p>
                          <p className="text-2xl font-bold text-white">{grammarProgress}%</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-white/5 rounded-full -mr-64 -mt-64 blur-[120px] pointer-events-none" />
                  <div className="absolute bottom-0 left-0 w-[300px] h-[300px] bg-indigo-500/10 rounded-full -ml-32 -mb-32 blur-[100px] pointer-events-none" />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
                  <button 
                    onClick={() => setView('grammar')}
                    className="bento-card flex items-center gap-8 group text-left"
                  >
                    <div className="bg-emerald-50 p-6 rounded-[32px] group-hover:scale-110 transition-transform duration-500">
                      <GraduationCap className="w-10 h-10 text-emerald-500" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-1">Grammar Guide</p>
                      <h4 className="text-2xl font-bold tracking-tight">{currentLevelContent.grammarRules?.length || 0} Rules</h4>
                      <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest mt-1.5 flex items-center gap-1">
                        <ChevronRight className="w-3 h-3" /> Explore
                      </p>
                    </div>
                  </button>
                  <div className="bento-card flex items-center gap-8 group">
                    <div className="bg-amber-50 p-6 rounded-[32px] group-hover:scale-110 transition-transform duration-500">
                      <Zap className="w-10 h-10 text-amber-500 fill-amber-500" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-1">Current Streak</p>
                      <h4 className="text-2xl font-bold tracking-tight">{progress?.streak || 0} Days</h4>
                      <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest mt-1.5 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Active Today
                      </p>
                    </div>
                  </div>
                  <div className="bento-card flex items-center gap-8 group">
                    <div className="bg-indigo-50 p-6 rounded-[32px] group-hover:scale-110 transition-transform duration-500">
                      <Star className="w-10 h-10 text-indigo-500 fill-indigo-500" />
                    </div>
                    <div>
                      <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-[0.2em] mb-1">Total Experience</p>
                      <h4 className="text-2xl font-bold tracking-tight">{progress?.xp || 0} XP</h4>
                      <p className="text-[10px] text-indigo-500 font-bold uppercase tracking-widest mt-1.5">
                        Rank: {getRank(progress?.xp || 0)}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {view === 'learn' && (
            <motion.div 
              key="learn"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-12"
            >
              {!isLevelUnlocked ? (
                <div className="text-center py-32 glass rounded-[64px] border border-zinc-100/50 flex flex-col items-center justify-center max-w-2xl mx-auto">
                  <div className="bg-zinc-50 p-8 rounded-[40px] mb-8">
                    <Lock className="w-16 h-16 text-zinc-200" />
                  </div>
                  <h3 className="text-2xl font-bold tracking-tight uppercase mb-4">Level {progress?.level} is Locked</h3>
                  <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs max-w-xs mx-auto leading-relaxed mb-10">You need to unlock this level to access its flashcards and dictionary.</p>
                  <button 
                    onClick={() => setView('payment')}
                    className="bg-zinc-900 text-white px-10 py-5 rounded-[24px] font-bold uppercase tracking-widest text-xs hover:scale-[1.05] active:scale-[0.98] transition-all shadow-2xl shadow-zinc-900/20"
                  >
                    Unlock Now
                  </button>
                </div>
              ) : (
                <>
                  <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
                <div className="flex flex-col gap-4">
                  <div>
                    <h2 className="text-3xl font-bold tracking-tight uppercase mb-2">{progress?.level} Vocabulary</h2>
                    <p className="text-zinc-400 font-bold uppercase tracking-[0.2em] text-[10px]">Mastering {filteredFlashcards.length} items in this category.</p>
                  </div>
                  
                  <div className="flex bg-zinc-100/50 p-1.5 rounded-2xl border border-zinc-200/50 w-fit">
                    <button 
                      onClick={() => setLearnMode('flashcard')}
                      className={`px-6 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${learnMode === 'flashcard' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
                    >
                      Flashcards
                    </button>
                    <button 
                      onClick={() => setLearnMode('dictionary')}
                      className={`px-6 py-2 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all ${learnMode === 'dictionary' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'}`}
                    >
                      Dictionary
                    </button>
                  </div>
                </div>

                <div className="flex bg-zinc-100/50 p-1.5 rounded-2xl border border-zinc-200/50 backdrop-blur-md overflow-x-auto max-w-full">
                  {wordTypes.map(type => (
                    <button 
                      key={type}
                      onClick={() => { setSelectedWordType(type); setCurrentCardIndex(0); }}
                      className={`px-6 py-2.5 rounded-xl text-[10px] font-bold uppercase tracking-widest transition-all duration-300 whitespace-nowrap ${selectedWordType === type ? 'bg-zinc-900 text-white shadow-xl scale-[1.05]' : 'text-zinc-400 hover:text-zinc-600'}`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </header>

              {filteredFlashcards.length > 0 ? (
                learnMode === 'flashcard' ? (
                  <div className="space-y-12">
                    <div className="flex justify-between items-center text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-400 px-4">
                      <span>Item {currentCardIndex + 1} of {filteredFlashcards.length}</span>
                      <div className="flex gap-1">
                        {filteredFlashcards.slice(0, Math.min(filteredFlashcards.length, 20)).map((_, idx) => (
                          <div key={idx} className={`h-1 rounded-full transition-all duration-500 ${idx === currentCardIndex ? 'w-8 bg-zinc-900' : 'w-2 bg-zinc-200'}`} />
                        ))}
                      </div>
                    </div>
                    <FlashcardComponent 
                      card={filteredFlashcards[currentCardIndex]}
                      onNext={() => setCurrentCardIndex((currentCardIndex + 1) % filteredFlashcards.length)}
                      onPrev={() => setCurrentCardIndex((currentCardIndex - 1 + filteredFlashcards.length) % filteredFlashcards.length)}
                      isFavorite={progress?.favorites?.includes(filteredFlashcards[currentCardIndex]?.id) || false}
                      isBookmarked={progress?.bookmarks?.includes(filteredFlashcards[currentCardIndex]?.id) || false}
                      onToggleFavorite={() => handleToggleFavorite(filteredFlashcards[currentCardIndex]?.id)}
                      onToggleBookmark={() => handleToggleBookmark(filteredFlashcards[currentCardIndex]?.id)}
                    />
                  </div>
                ) : (
                  <DictionaryView 
                    flashcards={filteredFlashcards}
                    favorites={progress?.favorites || []}
                    onToggleFavorite={handleToggleFavorite}
                    onSpeak={handleSpeak}
                  />
                )
              ) : (
                <div className="text-center py-32 glass rounded-[64px] border border-zinc-100/50 flex flex-col items-center justify-center">
                  <div className="bg-zinc-50 p-8 rounded-[40px] mb-8">
                    <Search className="w-16 h-16 text-zinc-200" />
                  </div>
                  <h3 className="text-2xl font-bold tracking-tight uppercase mb-4">No flashcards found</h3>
                  <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs max-w-xs mx-auto leading-relaxed">Try selecting a different word type or level to continue your journey.</p>
                </div>
              )}
            </>
          )}
        </motion.div>
      )}

          {view === 'quiz' && (
            <motion.div 
              key="quiz"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="space-y-12"
            >
              {!isLevelUnlocked ? (
                <div className="text-center py-32 glass rounded-[64px] border border-zinc-100/50 flex flex-col items-center justify-center max-w-2xl mx-auto">
                  <div className="bg-zinc-50 p-8 rounded-[40px] mb-8">
                    <Lock className="w-16 h-16 text-zinc-200" />
                  </div>
                  <h3 className="text-2xl font-bold tracking-tight uppercase mb-4">Level {progress?.level} is Locked</h3>
                  <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs max-w-xs mx-auto leading-relaxed mb-10">Unlock this level to test your knowledge with quizzes.</p>
                  <button 
                    onClick={() => setView('payment')}
                    className="bg-zinc-900 text-white px-10 py-5 rounded-[24px] font-bold uppercase tracking-widest text-xs hover:scale-[1.05] active:scale-[0.98] transition-all shadow-2xl shadow-zinc-900/20"
                  >
                    Unlock Now
                  </button>
                </div>
              ) : (
                <>
                  {!quizType ? (
                <div className="max-w-5xl mx-auto space-y-16">
                  <header className="text-center space-y-6">
                    <div className="inline-block bg-zinc-100 px-6 py-2 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-500 mb-4">Knowledge Assessment</div>
                    <h2 className="text-5xl font-bold tracking-tight uppercase">{progress?.level} Mastery Check</h2>
                    <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs max-w-md mx-auto">Challenge yourself and earn XP to climb the ranks of German mastery.</p>
                  </header>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    <button 
                      onClick={() => setQuizType('vocabulary')}
                      className="bento-card p-12 text-left group relative overflow-hidden"
                    >
                      <div className="relative z-10">
                        <div className="bg-indigo-50 w-20 h-20 rounded-[32px] flex items-center justify-center mb-10 group-hover:scale-110 group-hover:rotate-6 transition-all duration-500">
                          <BookOpen className="w-10 h-10 text-indigo-600" />
                        </div>
                        <h3 className="text-2xl font-bold tracking-tight uppercase mb-4">Vocabulary Quiz</h3>
                        <p className="text-zinc-400 font-medium text-sm mb-10 leading-relaxed">Test your command over words, their meanings, and contextual usage in real-world scenarios.</p>
                        <div className="flex items-center justify-between pt-8 border-t border-zinc-50">
                          <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-widest mb-1">Available Tasks</span>
                            <span className="text-xl font-bold text-zinc-900">{vocabQuizzes.length} Questions</span>
                          </div>
                          <div className="bg-zinc-900 text-white p-4 rounded-2xl group-hover:translate-x-2 transition-transform shadow-xl shadow-zinc-900/20">
                            <ChevronRight className="w-6 h-6" />
                          </div>
                        </div>
                      </div>
                      <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/5 rounded-full -mr-32 -mt-32 blur-3xl pointer-events-none" />
                    </button>

                    <button 
                      onClick={() => setQuizType('grammar')}
                      className="bento-card p-12 text-left group relative overflow-hidden"
                    >
                      <div className="relative z-10">
                        <div className="bg-emerald-50 w-20 h-20 rounded-[32px] flex items-center justify-center mb-10 group-hover:scale-110 group-hover:-rotate-6 transition-all duration-500">
                          <Zap className="w-10 h-10 text-emerald-600" />
                        </div>
                        <h3 className="text-2xl font-bold tracking-tight uppercase mb-4">Grammar Quiz</h3>
                        <p className="text-zinc-400 font-medium text-sm mb-10 leading-relaxed">Master the intricate architecture of German sentences, cases, and complex conjugations.</p>
                        <div className="flex items-center justify-between pt-8 border-t border-zinc-50">
                          <div className="flex flex-col">
                            <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-widest mb-1">Available Tasks</span>
                            <span className="text-xl font-bold text-zinc-900">{grammarQuizzes.length} Questions</span>
                          </div>
                          <div className="bg-zinc-900 text-white p-4 rounded-2xl group-hover:translate-x-2 transition-transform shadow-xl shadow-zinc-900/20">
                            <ChevronRight className="w-6 h-6" />
                          </div>
                        </div>
                      </div>
                      <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/5 rounded-full -mr-32 -mt-32 blur-3xl pointer-events-none" />
                    </button>
                  </div>
                </div>
              ) : (
                <div className="space-y-12 max-w-4xl mx-auto">
                  <div className="flex items-center justify-between px-4">
                    <button 
                      onClick={() => setQuizType(null)}
                      className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400 hover:text-zinc-900 flex items-center gap-3 transition-colors group"
                    >
                      <div className="bg-zinc-100 p-2 rounded-xl group-hover:bg-zinc-200 transition-colors">
                        <ChevronLeft className="w-4 h-4" />
                      </div>
                      Back to Selection
                    </button>
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${quizType === 'vocabulary' ? 'bg-indigo-500' : 'bg-emerald-500'} animate-pulse`} />
                      <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-900">{quizType} Assessment</span>
                    </div>
                  </div>

                  {(quizType === 'vocabulary' ? vocabQuizzes : grammarQuizzes).length > 0 ? (
                    <QuizComponent 
                      questions={quizType === 'vocabulary' ? vocabQuizzes : grammarQuizzes}
                      onComplete={(score) => {
                        const xpGained = score * 10;
                        const currentScores = progress?.quizScores || { vocabulary: 0, grammar: 0, totalAttempts: 0 };
                        
                        const totalQuestions = (quizType === 'vocabulary' ? vocabQuizzes : grammarQuizzes).length;
                        const percentage = Math.round((score / totalQuestions) * 100);
                        
                        const newScores = {
                          ...currentScores,
                          [quizType]: Math.round((currentScores[quizType] + percentage) / (currentScores.totalAttempts > 0 ? 2 : 1)),
                          totalAttempts: currentScores.totalAttempts + 1
                        };

                        updateProgress({ 
                          xp: (progress?.xp || 0) + xpGained,
                          quizScores: newScores
                        });
                        setQuizType(null);
                      }}
                    />
                  ) : (
                    <div className="text-center py-32 glass rounded-[64px] border border-zinc-100/50 flex flex-col items-center justify-center max-w-2xl mx-auto">
                      <div className="bg-zinc-50 p-8 rounded-[40px] mb-8">
                        <Zap className="w-16 h-16 text-zinc-200" />
                      </div>
                      <h3 className="text-2xl font-bold tracking-tight uppercase mb-4">No {quizType} quizzes available</h3>
                      <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs max-w-xs mx-auto leading-relaxed mb-10">Check back later for new challenges in {progress?.level}.</p>
                      <button 
                        onClick={() => setQuizType(null)}
                        className="bg-zinc-900 text-white px-10 py-5 rounded-[24px] font-bold uppercase tracking-widest text-xs hover:scale-[1.05] active:scale-[0.98] transition-all shadow-2xl shadow-zinc-900/20"
                      >
                        Return to Selection
                      </button>
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </motion.div>
      )}

          {view === 'favorites' && (
            <motion.div 
              key="favorites"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-12"
            >
              <header>
                <h2 className="text-3xl font-bold tracking-tight uppercase mb-2">Favorite Words</h2>
                <p className="text-zinc-500">You have {favoriteFlashcards.length} words in your collection.</p>
              </header>

              <div className="grid grid-cols-3 gap-6">
                {favoriteFlashcards.map(card => (
                  <div key={card.id} className="bg-white p-8 rounded-[32px] shadow-sm border border-zinc-100 hover:shadow-xl hover:-translate-y-1 transition-all group">
                    <div className="flex justify-between items-start mb-6">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">{card.wordType}</span>
                      <button onClick={() => handleToggleFavorite(card.id)} className="text-rose-500">
                        <Star className="w-5 h-5 fill-current" />
                      </button>
                    </div>
                    <h3 className="text-2xl font-bold mb-2">{card.german}</h3>
                    <p className="text-zinc-500 mb-6">{card.english}</p>
                    <div className="pt-6 border-t border-zinc-50 flex justify-between items-center">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-300">{card.level}</span>
                      <button 
                        onClick={() => {
                          const utterance = new SpeechSynthesisUtterance(card.german);
                          utterance.lang = 'de-DE';
                          window.speechSynthesis.speak(utterance);
                        }}
                        className="p-2 bg-zinc-50 rounded-xl text-zinc-400 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {view === 'bookmarks' && (
            <motion.div 
              key="bookmarks"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-12"
            >
              <header>
                <h2 className="text-3xl font-bold tracking-tight uppercase mb-2">Bookmarked Cards</h2>
                <p className="text-zinc-500">Review these {bookmarkedFlashcards.length} cards later.</p>
              </header>

              <div className="grid grid-cols-3 gap-6">
                {bookmarkedFlashcards.map(card => (
                  <div key={card.id} className="bg-white p-8 rounded-[32px] shadow-sm border border-zinc-100 hover:shadow-xl hover:-translate-y-1 transition-all group">
                    <div className="flex justify-between items-start mb-6">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">{card.wordType}</span>
                      <button onClick={() => handleToggleBookmark(card.id)} className="text-zinc-900">
                        <BookmarkIcon className="w-5 h-5 fill-current" />
                      </button>
                    </div>
                    <h3 className="text-2xl font-bold mb-2">{card.german}</h3>
                    <p className="text-zinc-500 mb-6">{card.english}</p>
                    <div className="pt-6 border-t border-zinc-50 flex justify-between items-center">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-300">{card.level}</span>
                      <button 
                        onClick={() => {
                          const utterance = new SpeechSynthesisUtterance(card.german);
                          utterance.lang = 'de-DE';
                          window.speechSynthesis.speak(utterance);
                        }}
                        className="p-2 bg-zinc-50 rounded-xl text-zinc-400 opacity-0 group-hover:opacity-100 transition-all"
                      >
                        <Volume2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </motion.div>
          )}

          {view === 'grammar' && (
            <motion.div 
              key="grammar"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
            >
              {!isLevelUnlocked ? (
                <div className="text-center py-32 glass rounded-[64px] border border-zinc-100/50 flex flex-col items-center justify-center max-w-2xl mx-auto">
                  <div className="bg-zinc-50 p-8 rounded-[40px] mb-8">
                    <Lock className="w-16 h-16 text-zinc-200" />
                  </div>
                  <h3 className="text-2xl font-bold tracking-tight uppercase mb-4">Level {progress?.level} is Locked</h3>
                  <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs max-w-xs mx-auto leading-relaxed mb-10">Unlock this level to access grammar rules and guides.</p>
                  <button 
                    onClick={() => setView('payment')}
                    className="bg-zinc-900 text-white px-10 py-5 rounded-[24px] font-bold uppercase tracking-widest text-xs hover:scale-[1.05] active:scale-[0.98] transition-all shadow-2xl shadow-zinc-900/20"
                  >
                    Unlock Now
                  </button>
                </div>
              ) : (
                <GrammarSection rules={currentLevelContent.grammarRules || []} />
              )}
            </motion.div>
          )}

          {view === 'payment' && (
            <motion.div 
              key="payment"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
            >
              <Payment />
            </motion.div>
          )}

          {view === 'admin' && <AdminPanel />}
        </AnimatePresence>
      </main>
    </div>
  );
};

const Login = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-zinc-50 p-6">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full bg-white rounded-[40px] p-12 text-center shadow-2xl"
      >
        <div className="bg-zinc-900 w-20 h-20 rounded-3xl flex items-center justify-center mx-auto mb-8">
          <GraduationCap className="w-10 h-10 text-white" />
        </div>
        <h1 className="text-3xl font-bold tracking-tight text-zinc-900 mb-4 uppercase">DeutschMaster</h1>
        <p className="text-zinc-500 mb-12">Master German from A1 to C1 with modern interactive flashcards and quizzes.</p>
        
        <button 
          onClick={() => signInWithPopup(auth, googleProvider)}
          className="w-full bg-zinc-900 text-white py-5 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-zinc-800 transition-all shadow-xl shadow-zinc-900/20"
        >
          <img src="https://www.google.com/favicon.ico" className="w-5 h-5" alt="Google" />
          Continue with Google
        </button>
        
        <p className="mt-8 text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Start your journey to fluency today</p>
      </motion.div>
    </div>
  );
};

const AppContent = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-zinc-50">
        <motion.div 
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          className="w-12 h-12 border-4 border-zinc-200 border-t-zinc-900 rounded-full"
        />
      </div>
    );
  }

  return user ? <Dashboard /> : <Login />;
};

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <ContentProvider>
          <AppContent />
        </ContentProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
}
