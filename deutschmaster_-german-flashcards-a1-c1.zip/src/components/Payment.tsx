import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { Level } from '../types';
import { motion } from 'framer-motion';
import { 
  CheckCircle2, 
  Lock, 
  Zap, 
  Clock, 
  ShieldCheck
} from 'lucide-react';

const LEVEL_PRICES: Record<Level, number> = {
  'A1': 500,
  'A2': 700,
  'B1': 1000,
  'B2': 1200,
  'C1': 1500
};

export const Payment: React.FC = () => {
  const { progress, updateProgress } = useAuth();
  const [selectedLevel, setSelectedLevel] = useState<Level | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const levels: Level[] = ['A1', 'A2', 'B1', 'B2', 'C1'];

  const handlePayment = async (level: Level) => {
    setIsProcessing(true);
    // Simulate bKash payment delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const purchasedLevels = progress?.purchasedLevels || [];
    if (!purchasedLevels.includes(level)) {
      await updateProgress({
        purchasedLevels: [...purchasedLevels, level]
      });
    }
    
    setIsProcessing(false);
    setShowSuccess(true);
    setTimeout(() => setShowSuccess(false), 3000);
  };

  const getTrialStatus = () => {
    if (!progress?.createdAt) return { active: false, days: 0, hours: 0 };
    
    let createdAtDate: Date;
    if (progress.createdAt instanceof Date) {
      createdAtDate = progress.createdAt;
    } else if (typeof (progress.createdAt as { toDate?: () => Date })?.toDate === 'function') {
      createdAtDate = (progress.createdAt as { toDate: () => Date }).toDate();
    } else if ((progress.createdAt as { seconds: number })?.seconds !== undefined) {
      createdAtDate = new Date((progress.createdAt as { seconds: number }).seconds * 1000);
    } else {
      createdAtDate = new Date();
    }
    
    const trialMs = 3 * 24 * 60 * 60 * 1000;
    const now = new Date();
    const diff = now.getTime() - createdAtDate.getTime();
    const remaining = Math.max(0, trialMs - diff);
    const days = Math.floor(remaining / (24 * 60 * 60 * 1000));
    const hours = Math.floor((remaining % (24 * 60 * 60 * 1000)) / (60 * 60 * 1000));

    return { active: diff < trialMs, days, hours };
  };

  const trial = getTrialStatus();

  return (
    <div className="max-w-5xl mx-auto space-y-12 pb-20">
      <header className="text-center space-y-4">
        <div className="inline-block bg-zinc-100 px-6 py-2 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-500 mb-4">Premium Access</div>
        <h1 className="text-5xl font-black tracking-tighter uppercase">Unlock Your Potential</h1>
        <p className="text-zinc-500 max-w-xl mx-auto font-medium">
          Get lifetime access to professional German learning content. Pay once per level and master the language at your own pace.
        </p>
      </header>

      {trial?.active && (
        <div className="bg-emerald-50 border border-emerald-100 p-8 rounded-[40px] flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-6">
            <div className="bg-white p-4 rounded-3xl shadow-sm">
              <Clock className="w-8 h-8 text-emerald-500" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-emerald-900">Free Trial Active</h3>
              <p className="text-emerald-600 font-medium">You have full access to A1 content for {trial.days}d {trial.hours}h more.</p>
            </div>
          </div>
          <div className="bg-white/50 px-6 py-3 rounded-2xl border border-emerald-200">
            <span className="text-xs font-bold uppercase tracking-widest text-emerald-700">Level A1 Unlocked</span>
          </div>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {levels.map((level) => {
          const isPurchased = progress?.purchasedLevels?.includes(level);
          const isTrial = level === 'A1' && trial?.active;
          const isUnlocked = isPurchased || isTrial || progress?.role === 'admin';
          const price = LEVEL_PRICES[level];

          return (
            <div 
              key={level}
              className={`relative group bg-white rounded-[48px] p-8 border-2 transition-all duration-500 ${isUnlocked ? 'border-emerald-500/20 shadow-xl shadow-emerald-500/5' : 'border-zinc-100 hover:border-zinc-300 shadow-sm'}`}
            >
              <div className="flex justify-between items-start mb-8">
                <div className={`w-16 h-16 rounded-3xl flex items-center justify-center text-2xl font-black ${isUnlocked ? 'bg-emerald-500 text-white' : 'bg-zinc-100 text-zinc-400'}`}>
                  {level}
                </div>
                {isUnlocked ? (
                  <div className="bg-emerald-50 text-emerald-600 p-2 rounded-xl">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                ) : (
                  <div className="bg-zinc-50 text-zinc-300 p-2 rounded-xl">
                    <Lock className="w-6 h-6" />
                  </div>
                )}
              </div>

              <div className="space-y-2 mb-8">
                <h3 className="text-2xl font-bold text-zinc-900">Level {level}</h3>
                <p className="text-zinc-400 text-sm font-medium">
                  {level === 'A1' ? 'Beginner Essentials' : 
                   level === 'A2' ? 'Elementary Mastery' :
                   level === 'B1' ? 'Intermediate Fluency' :
                   level === 'B2' ? 'Upper Intermediate' :
                   level === 'C1' ? 'Advanced Proficiency' : 'Near-Native Mastery'}
                </p>
              </div>

              <div className="space-y-4 mb-10">
                <div className="flex items-center gap-3 text-zinc-500 text-sm font-medium">
                  <ShieldCheck className="w-4 h-4 text-emerald-500" />
                  Lifetime Access
                </div>
                <div className="flex items-center gap-3 text-zinc-500 text-sm font-medium">
                  <Zap className="w-4 h-4 text-amber-500" />
                  All Quizzes & Grammar
                </div>
              </div>

              <div className="pt-8 border-t border-zinc-50 flex items-center justify-between">
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Price</p>
                  <p className="text-2xl font-black text-zinc-900">{price} BDT</p>
                </div>
                
                {isUnlocked ? (
                  <span className="text-xs font-bold uppercase tracking-widest text-emerald-500">Unlocked</span>
                ) : (
                  <button 
                    onClick={() => setSelectedLevel(level)}
                    className="bg-zinc-900 text-white px-6 py-3 rounded-2xl font-bold text-xs uppercase tracking-widest hover:bg-zinc-800 transition-all shadow-lg shadow-zinc-900/20"
                  >
                    Unlock
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Payment Modal */}
      {selectedLevel && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-md z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="bg-white rounded-[48px] w-full max-w-md p-12 shadow-2xl relative overflow-hidden"
          >
            <div className="absolute top-0 left-0 w-full h-2 bg-pink-500" />
            
            <div className="text-center space-y-6">
              <div className="bg-pink-50 w-24 h-24 rounded-[40px] flex items-center justify-center mx-auto mb-8">
                <img src="https://www.logo.wine/a/logo/BKash/BKash-Icon-Logo.wine.svg" className="w-16 h-16" alt="bKash" />
              </div>
              
              <h2 className="text-3xl font-black tracking-tighter uppercase">bKash Payment</h2>
              <p className="text-zinc-500 font-medium">
                You are unlocking <span className="text-zinc-900 font-bold">Level {selectedLevel}</span> for <span className="text-zinc-900 font-bold">{LEVEL_PRICES[selectedLevel]} BDT</span>.
              </p>

              <div className="bg-zinc-50 p-6 rounded-3xl text-left space-y-4">
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-400 font-bold uppercase tracking-widest text-[10px]">Merchant</span>
                  <span className="text-zinc-900 font-bold">DeutschMaster</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-zinc-400 font-bold uppercase tracking-widest text-[10px]">Amount</span>
                  <span className="text-zinc-900 font-bold">{LEVEL_PRICES[selectedLevel]} BDT</span>
                </div>
              </div>

              <div className="pt-8 space-y-4">
                <button 
                  onClick={() => handlePayment(selectedLevel)}
                  disabled={isProcessing}
                  className="w-full bg-[#D12053] text-white py-5 rounded-[24px] font-bold uppercase tracking-widest text-sm hover:bg-[#B01B46] transition-all shadow-xl shadow-pink-500/20 flex items-center justify-center gap-3"
                >
                  {isProcessing ? (
                    <>
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Processing...
                    </>
                  ) : (
                    <>Confirm Payment</>
                  )}
                </button>
                <button 
                  onClick={() => setSelectedLevel(null)}
                  disabled={isProcessing}
                  className="w-full py-4 text-zinc-400 font-bold uppercase tracking-widest text-[10px] hover:text-zinc-600 transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          </motion.div>
        </div>
      )}

      {/* Success Toast */}
      {showSuccess && (
        <div className="fixed bottom-12 left-1/2 -translate-x-1/2 z-[110]">
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-emerald-500 text-white px-8 py-4 rounded-2xl shadow-2xl flex items-center gap-3 font-bold uppercase tracking-widest text-xs"
          >
            <CheckCircle2 className="w-5 h-5" />
            Payment Successful! Level Unlocked.
          </motion.div>
        </div>
      )}
    </div>
  );
};
