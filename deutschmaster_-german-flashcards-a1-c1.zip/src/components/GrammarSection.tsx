import React, { useState } from 'react';
import { GrammarRule } from '../types';
import { motion } from 'framer-motion';
import { ChevronRight, ChevronLeft, BookOpen, GraduationCap, Volume2 } from 'lucide-react';
import Markdown from 'react-markdown';
import remarkBreaks from 'remark-breaks';
import remarkGfm from 'remark-gfm';
import { generateSpeech, playAudio } from '../services/gemini';

interface GrammarSectionProps {
  rules: GrammarRule[];
}

export const GrammarSection: React.FC<GrammarSectionProps> = ({ rules }) => {
  const [selectedRule, setSelectedRule] = useState<GrammarRule | null>(null);
  const [speaking, setSpeaking] = useState<string | null>(null);

  const handleSpeak = async (text: string) => {
    setSpeaking(text);
    try {
      const audio = await generateSpeech(text);
      if (audio) {
        await playAudio(audio.data, audio.mimeType);
      }
    } catch (error) {
      console.error("Audio error:", error);
    } finally {
      setSpeaking(null);
    }
  };

  if (selectedRule) {
    return (
      <div className="space-y-8">
        <button 
          onClick={() => setSelectedRule(null)}
          className="flex items-center gap-2 text-zinc-400 hover:text-zinc-900 font-bold text-xs uppercase tracking-widest transition-all"
        >
          <ChevronLeft className="w-4 h-4" /> Back to Rules
        </button>

        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-[40px] p-8 sm:p-12 shadow-sm border border-zinc-100"
        >
          <div className="space-y-8">
            <header className="space-y-2">
              <span className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest px-3 py-1 bg-emerald-50 rounded-full">
                {selectedRule.category}
              </span>
              <h2 className="text-4xl font-black tracking-tighter uppercase">{selectedRule.title}</h2>
            </header>

            <div className="prose prose-zinc max-w-none prose-headings:font-black prose-headings:uppercase prose-headings:tracking-tighter">
              <Markdown remarkPlugins={[remarkBreaks, remarkGfm]}>{selectedRule.explanation}</Markdown>
            </div>

            {selectedRule.examples.length > 0 && (
              <div className="space-y-6 pt-8 border-t border-zinc-100">
                <h3 className="text-xl font-black uppercase tracking-tighter flex items-center gap-2">
                  <BookOpen className="w-5 h-5" /> Examples
                </h3>
                <div className="grid gap-4">
                  {selectedRule.examples.map((ex, i) => (
                    <div key={i} className="bg-zinc-50 rounded-2xl p-6 flex justify-between items-center group">
                      <div className="space-y-1">
                        <p className="text-lg font-bold text-zinc-900">{ex.german}</p>
                        <p className="text-sm text-zinc-500 italic">{ex.english}</p>
                      </div>
                      <button 
                        onClick={() => handleSpeak(ex.german)}
                        disabled={speaking === ex.german}
                        className={`p-3 rounded-xl transition-all ${speaking === ex.german ? 'bg-zinc-900 text-white animate-pulse' : 'bg-white text-zinc-400 hover:text-zinc-900 hover:shadow-md'}`}
                      >
                        <Volume2 className="w-5 h-5" />
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </motion.div>
      </div>
    );
  }

  const categories = Array.from(new Set(rules.map(r => r.category)));

  return (
    <div className="space-y-12">
      <header>
        <h2 className="text-4xl font-black tracking-tighter uppercase flex items-center gap-3">
          <GraduationCap className="w-10 h-10" /> Grammar Guide
        </h2>
        <p className="text-zinc-500 mt-2">Master German grammar with clear explanations and examples.</p>
      </header>

      {categories.length === 0 ? (
        <div className="bg-zinc-50 rounded-[40px] p-12 text-center">
          <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs">No grammar rules found for this level yet.</p>
        </div>
      ) : (
        <div className="space-y-12">
          {categories.map(category => (
            <section key={category} className="space-y-6">
              <h3 className="text-xs font-black uppercase tracking-widest text-zinc-400 px-4">{category}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {rules.filter(r => r.category === category).map(rule => (
                  <button
                    key={rule.id}
                    onClick={() => setSelectedRule(rule)}
                    className="bg-white p-8 rounded-[32px] border border-zinc-100 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all text-left group"
                  >
                    <div className="flex justify-between items-start">
                      <div className="space-y-2">
                        <h4 className="text-xl font-black uppercase tracking-tighter group-hover:text-emerald-500 transition-colors">{rule.title}</h4>
                        <p className="text-sm text-zinc-500 line-clamp-2">{rule.explanation.replace(/[#*`]/g, '')}</p>
                      </div>
                      <div className="bg-zinc-50 p-2 rounded-xl group-hover:bg-emerald-500 group-hover:text-white transition-all">
                        <ChevronRight className="w-5 h-5" />
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
};
