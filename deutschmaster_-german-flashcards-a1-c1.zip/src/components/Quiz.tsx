import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { QuizQuestion } from '../types';
import { CheckCircle2, XCircle, ChevronRight, HelpCircle, Volume2, Loader2 } from 'lucide-react';
import { generateSpeech, playAudio } from '../services/gemini';

interface Props {
  questions: QuizQuestion[];
  onComplete: (score: number) => void;
}

export const QuizComponent: React.FC<Props> = ({ questions, onComplete }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedOption, setSelectedOption] = useState<string | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);
  const [isAudioLoading, setIsAudioLoading] = useState(false);

  const currentQuestion = questions[currentIndex];

  const handleSpeak = async (text: string) => {
    setIsAudioLoading(true);
    try {
      const audioData = await generateSpeech(text);
      if (audioData) {
        playAudio(audioData.data, audioData.mimeType || 'audio/mpeg');
      } else {
        // Fallback to browser TTS if Gemini fails
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'de-DE';
        window.speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error("Audio Error:", error);
      // Fallback
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'de-DE';
      window.speechSynthesis.speak(utterance);
    } finally {
      setIsAudioLoading(false);
    }
  };

  const handleOptionSelect = (option: string) => {
    if (isAnswered || !currentQuestion) return;
    setSelectedOption(option);
    setIsAnswered(true);
    if (option === currentQuestion.correctAnswer) {
      setScore(score + 1);
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setCurrentIndex(currentIndex + 1);
      setSelectedOption(null);
      setIsAnswered(false);
    } else {
      setShowResult(true);
      onComplete(score);
    }
  };

  if (!currentQuestion) {
    return (
      <div className="text-center py-12">
        <p className="text-zinc-500">Error: Question data is missing.</p>
      </div>
    );
  }

  if (showResult) {
    return (
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="glass rounded-[64px] p-16 text-center border border-zinc-100/50 max-w-2xl mx-auto shadow-[0_40px_100px_-20px_rgba(0,0,0,0.1)]"
      >
        <div className="w-24 h-24 bg-emerald-50 rounded-[32px] flex items-center justify-center mx-auto mb-10 shadow-xl shadow-emerald-500/10">
          <CheckCircle2 className="w-12 h-12 text-emerald-600" />
        </div>
        <div className="inline-block bg-zinc-100 px-6 py-2 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-500 mb-6">Assessment Complete</div>
        <h2 className="text-4xl font-bold tracking-tight uppercase mb-4">Exceptional Work!</h2>
        <p className="text-zinc-400 font-bold uppercase tracking-widest text-xs mb-12">You've successfully completed the knowledge check.</p>
        
        <div className="grid grid-cols-2 gap-8 mb-16">
          <div className="bg-zinc-50 rounded-[32px] p-8">
            <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-widest block mb-2">Accuracy</span>
            <span className="text-4xl font-bold text-zinc-900">{Math.round((score / questions.length) * 100)}%</span>
          </div>
          <div className="bg-zinc-900 rounded-[32px] p-8 text-white">
            <span className="text-[10px] font-bold text-white/40 uppercase tracking-widest block mb-2">XP Gained</span>
            <span className="text-4xl font-bold">+{score * 10}</span>
          </div>
        </div>

        <button 
          onClick={() => window.location.reload()}
          className="w-full bg-zinc-900 text-white py-6 rounded-[24px] font-bold uppercase tracking-widest text-xs hover:scale-[1.02] active:scale-[0.98] transition-all shadow-2xl shadow-zinc-900/20"
        >
          Return to Dashboard
        </button>
      </motion.div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-12">
      <div className="flex justify-between items-center px-8">
        <div className="flex flex-col">
          <span className="text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-300 mb-1">Progress</span>
          <span className="text-sm font-bold text-zinc-900">Task {currentIndex + 1} of {questions.length}</span>
        </div>
        <div className="flex gap-2">
          {questions.map((_, i) => (
            <div key={i} className={`h-1.5 rounded-full transition-all duration-500 ${i === currentIndex ? 'w-12 bg-zinc-900' : i < currentIndex ? 'w-4 bg-zinc-400' : 'w-2 bg-zinc-100'}`} />
          ))}
        </div>
      </div>

      <motion.div 
        key={currentIndex}
        initial={{ opacity: 0, x: 40 }}
        animate={{ opacity: 1, x: 0 }}
        className="glass rounded-[64px] p-16 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.1)] border border-zinc-100/50 relative overflow-hidden"
      >
        <div className="relative z-10">
          <div className="flex items-start gap-8 mb-12">
            <div className="flex flex-col gap-3">
              <div className="p-5 bg-zinc-50 rounded-[24px] text-zinc-400 shadow-sm">
                <HelpCircle className="w-8 h-8" />
              </div>
              <button 
                onClick={() => handleSpeak(currentQuestion.question)}
                disabled={isAudioLoading}
                className="p-3 bg-zinc-900 text-white rounded-2xl hover:scale-110 active:scale-95 transition-all shadow-lg disabled:opacity-50"
              >
                {isAudioLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Volume2 className="w-4 h-4" />}
              </button>
            </div>
            <h2 className="text-3xl font-bold tracking-tight text-zinc-900 leading-[1.1]">{currentQuestion.question}</h2>
          </div>

          <div className="grid grid-cols-1 gap-5">
            {(currentQuestion.options || []).map((option, i) => {
              const isCorrect = option === currentQuestion.correctAnswer;
              const isSelected = option === selectedOption;
              
              let buttonClass = "w-full p-8 rounded-[32px] text-left font-bold transition-all border-2 flex items-center justify-between group ";
              if (!isAnswered) {
                buttonClass += "bg-white border-zinc-100 hover:border-zinc-900 hover:shadow-xl hover:-translate-y-1";
              } else if (isCorrect) {
                buttonClass += "bg-emerald-50 border-emerald-500 text-emerald-700 shadow-lg shadow-emerald-500/10";
              } else if (isSelected && !isCorrect) {
                buttonClass += "bg-rose-50 border-rose-500 text-rose-700 shadow-lg shadow-rose-500/10";
              } else {
                buttonClass += "bg-zinc-50 border-transparent opacity-40 grayscale";
              }

              return (
                <button
                  key={`${i}-${option}`}
                  onClick={() => handleOptionSelect(option)}
                  disabled={isAnswered}
                  className={buttonClass}
                >
                  <span className="text-lg tracking-tight">{option}</span>
                  <div className="flex items-center gap-4">
                    {isAnswered && isCorrect && <CheckCircle2 className="w-6 h-6" />}
                    {isAnswered && isSelected && !isCorrect && <XCircle className="w-6 h-6" />}
                    {!isAnswered && <div className="w-8 h-8 rounded-full border-2 border-zinc-100 group-hover:border-zinc-900 transition-colors" />}
                  </div>
                </button>
              );
            })}
          </div>

          <AnimatePresence>
            {isAnswered && (
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-12 pt-12 border-t border-zinc-100"
              >
                <div className="bg-zinc-50 rounded-[32px] p-10 mb-10">
                  <span className="text-[10px] font-bold text-zinc-300 uppercase tracking-[0.3em] block mb-4">Expert Insight</span>
                  <p className="text-zinc-600 font-medium text-lg leading-relaxed">
                    "{currentQuestion.explanation}"
                  </p>
                </div>
                <button 
                  onClick={handleNext}
                  className="w-full bg-zinc-900 text-white py-6 rounded-[24px] font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-4 hover:scale-[1.02] active:scale-[0.98] transition-all shadow-2xl shadow-zinc-900/20"
                >
                  Proceed to Next Task <ChevronRight className="w-5 h-5" />
                </button>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
        <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-zinc-50 rounded-full blur-3xl opacity-50 pointer-events-none" />
      </motion.div>
    </div>
  );
};
