import { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { useContent } from '../context/ContentContext';
import { Level, Flashcard, QuizQuestion, WordType, GrammarRule } from '../types';
import { db, doc, setDoc, serverTimestamp, handleFirestoreError, OperationType } from '../firebase';
import { motion } from 'framer-motion';
import { 
  Save, 
  Plus, 
  Trash2, 
  AlertCircle, 
  CheckCircle2,
  ChevronRight,
  BookOpen,
  HelpCircle,
  Upload,
  GraduationCap
} from 'lucide-react';

export const AdminPanel: React.FC = () => {
  const { progress, user } = useAuth();
  const { content } = useContent();
  const [selectedLevel, setSelectedLevel] = useState<Level>('A1');
  const [activeTab, setActiveTab] = useState<'flashcards' | 'quizzes' | 'grammar' | 'bulk'>('flashcards');
  const [bulkType, setBulkType] = useState<'flashcards' | 'vocab-quizzes' | 'grammar-quizzes' | 'grammar-rules'>('vocab-quizzes');
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);
  const [editingItem, setEditingItem] = useState<{ type: 'flashcard' | 'quiz' | 'grammar', data: Flashcard | QuizQuestion | GrammarRule } | null>(null);
  const [bulkText, setBulkText] = useState('');
  const [quizFilter, setQuizFilter] = useState<'all' | 'vocabulary' | 'grammar'>('all');
  const [confirmModal, setConfirmModal] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
  }>({
    isOpen: false,
    title: '',
    message: '',
    onConfirm: () => {}
  });

  if (progress?.role !== 'admin' && user?.email !== 'onik30001@gmail.com') {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="text-center space-y-4">
          <AlertCircle className="w-12 h-12 text-rose-500 mx-auto" />
          <h1 className="text-2xl font-black uppercase tracking-tighter">Access Denied</h1>
          <p className="text-zinc-500">You do not have administrative privileges.</p>
        </div>
      </div>
    );
  }

  const handleSyncToFirestore = async () => {
    setIsSaving(true);
    setMessage(null);
    try {
      for (const [level, levelContent] of Object.entries(content) as [string, { flashcards: Flashcard[], quizzes: QuizQuestion[], grammarRules: GrammarRule[] }][]) {
        await setDoc(doc(db, 'content', level), {
          ...levelContent,
          updatedAt: serverTimestamp()
        });
      }
      setMessage({ type: 'success', text: 'All content synced to Firestore successfully!' });
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'content');
      setMessage({ type: 'error', text: 'Failed to sync content.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;
    setIsSaving(true);
    try {
      const levelContent = { ...content[selectedLevel] };
      if (editingItem.type === 'flashcard') {
        const idx = levelContent.flashcards.findIndex(f => f.id === editingItem.data.id);
        if (idx > -1) {
          levelContent.flashcards[idx] = editingItem.data as Flashcard;
        } else {
          levelContent.flashcards.push(editingItem.data as Flashcard);
        }
      } else if (editingItem.type === 'quiz') {
        const idx = levelContent.quizzes.findIndex(q => q.id === editingItem.data.id);
        if (idx > -1) {
          levelContent.quizzes[idx] = editingItem.data as QuizQuestion;
        } else {
          levelContent.quizzes.push(editingItem.data as QuizQuestion);
        }
      } else {
        const idx = levelContent.grammarRules.findIndex(g => g.id === editingItem.data.id);
        if (idx > -1) {
          levelContent.grammarRules[idx] = editingItem.data as GrammarRule;
        } else {
          levelContent.grammarRules.push(editingItem.data as GrammarRule);
        }
      }

      await setDoc(doc(db, 'content', selectedLevel), {
        ...levelContent,
        updatedAt: serverTimestamp()
      });
      setMessage({ type: 'success', text: 'Item saved successfully!' });
      setEditingItem(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `content/${selectedLevel}`);
      setMessage({ type: 'error', text: 'Failed to save item.' });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDeleteItem = async (type: 'flashcard' | 'quiz' | 'grammar', id: string) => {
    setConfirmModal({
      isOpen: true,
      title: 'Delete Item',
      message: 'Are you sure you want to delete this item? This action cannot be undone.',
      onConfirm: async () => {
        setIsSaving(true);
        try {
          const levelContent = { ...content[selectedLevel] };
          if (type === 'flashcard') {
            levelContent.flashcards = levelContent.flashcards.filter(f => f.id !== id);
          } else if (type === 'quiz') {
            levelContent.quizzes = levelContent.quizzes.filter(q => q.id !== id);
          } else {
            levelContent.grammarRules = levelContent.grammarRules.filter(g => g.id !== id);
          }

          await setDoc(doc(db, 'content', selectedLevel), {
            ...levelContent,
            updatedAt: serverTimestamp()
          });
          setMessage({ type: 'success', text: 'Item deleted successfully!' });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `content/${selectedLevel}`);
          setMessage({ type: 'error', text: 'Failed to delete item.' });
        } finally {
          setIsSaving(false);
          setConfirmModal(prev => ({ ...prev, isOpen: false }));
        }
      }
    });
  };

  const handleClearAll = async () => {
    setConfirmModal({
      isOpen: true,
      title: 'Clear All Content',
      message: `Are you sure you want to delete ALL ${activeTab} for ${selectedLevel}? This cannot be undone.`,
      onConfirm: async () => {
        setIsSaving(true);
        setMessage(null);
        try {
          const levelContent = { ...content[selectedLevel] };
          if (activeTab === 'flashcards') {
            levelContent.flashcards = [];
          } else if (activeTab === 'quizzes') {
            levelContent.quizzes = [];
          } else {
            levelContent.grammarRules = [];
          }

          await setDoc(doc(db, 'content', selectedLevel), {
            ...levelContent,
            updatedAt: serverTimestamp()
          });
          
          setMessage({ type: 'success', text: `All ${activeTab} for ${selectedLevel} deleted successfully!` });
        } catch (error) {
          handleFirestoreError(error, OperationType.WRITE, `content/${selectedLevel}`);
          setMessage({ type: 'error', text: 'Failed to delete content.' });
        } finally {
          setIsSaving(false);
          setConfirmModal(prev => ({ ...prev, isOpen: false }));
        }
      }
    });
  };

  const handleBulkUpload = async () => {
    if (!bulkText.trim()) return;
    setIsSaving(true);
    setMessage(null);
    try {
      const newData = JSON.parse(bulkText);
      if (!Array.isArray(newData)) throw new Error('Input must be a JSON array');

      const levelContent = { ...content[selectedLevel] };
      
      if (bulkType === 'flashcards') {
        const processedCards = newData.map(c => ({
          ...c,
          id: c.id || `card-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          level: selectedLevel,
          type: c.type || 'vocabulary',
          wordType: c.wordType || 'Noun',
          category: c.category || 'General',
          frequency: c.frequency || undefined,
          bangla: c.bangla || undefined
        }));
        levelContent.flashcards = [...levelContent.flashcards, ...processedCards];
      } else if (bulkType === 'grammar-rules') {
        const processedRules = newData.map(g => ({
          ...g,
          id: g.id || `rule-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          level: selectedLevel,
          category: g.category || 'General',
          examples: g.examples || []
        }));
        levelContent.grammarRules = [...levelContent.grammarRules, ...processedRules];
      } else {
        const type = bulkType === 'vocab-quizzes' ? 'vocabulary' : 'grammar';
        const processedQuizzes = newData.map(q => ({
          ...q,
          id: q.id || `quiz-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          level: selectedLevel,
          type: q.type || type
        }));
        levelContent.quizzes = [...levelContent.quizzes, ...processedQuizzes];
      }

      await setDoc(doc(db, 'content', selectedLevel), {
        ...levelContent,
        updatedAt: serverTimestamp()
      });

      setMessage({ 
        type: 'success', 
        text: `Successfully added ${newData.length} ${bulkType.replace('-', ' ')}!` 
      });
      setBulkText('');
      if (bulkType === 'flashcards') setActiveTab('flashcards');
      else if (bulkType === 'grammar-rules') setActiveTab('grammar');
      else setActiveTab('quizzes');
    } catch (error) {
      if (error instanceof SyntaxError) {
        setMessage({ type: 'error', text: 'Invalid JSON format. Please check your syntax.' });
      } else {
        handleFirestoreError(error, OperationType.WRITE, `content/${selectedLevel}`);
        setMessage({ type: 'error', text: 'Failed to upload data.' });
      }
    } finally {
      setIsSaving(false);
    }
  };

  const getPlaceholder = () => {
    if (bulkType === 'flashcards') {
      return '[{\n  "german": "Haus",\n  "english": "House",\n  "bangla": "বাড়ি",\n  "example": "Das ist ein House.",\n  "wordType": "Noun",\n  "frequency": 1\n}]';
    }
    if (bulkType === 'grammar-rules') {
      return '[{\n  "title": "Present Tense",\n  "explanation": "How to use...",\n  "category": "Verbs",\n  "examples": [{"german": "Ich bin", "english": "I am"}]\n}]';
    }
    return '[{\n  "question": "What is...",\n  "options": ["A", "B", "C", "D"],\n  "correctAnswer": "A",\n  "explanation": "..."\n}]';
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-8">
      <header className="flex justify-between items-end">
        <div>
          <h1 className="text-4xl font-black tracking-tighter uppercase">Admin Panel</h1>
          <p className="text-zinc-500">Manage content and synchronize with database.</p>
        </div>
        <div className="flex gap-4">
          <div className="bg-white px-6 py-4 rounded-2xl border border-zinc-100 shadow-sm flex items-center gap-8">
            <div>
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Flashcards</p>
              <p className="text-xl font-black">{content[selectedLevel].flashcards.length}</p>
            </div>
            <div className="w-px h-8 bg-zinc-100" />
            <div>
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Quizzes</p>
              <p className="text-xl font-black">{content[selectedLevel].quizzes.length}</p>
            </div>
            <div className="w-px h-8 bg-zinc-100" />
            <div>
              <p className="text-[10px] font-bold text-zinc-400 uppercase tracking-widest">Grammar</p>
              <p className="text-xl font-black">{content[selectedLevel].grammarRules?.length || 0}</p>
            </div>
          </div>
          <button 
            onClick={handleSyncToFirestore}
            disabled={isSaving}
            className="bg-zinc-900 text-white px-8 py-4 rounded-2xl font-bold uppercase tracking-widest text-xs flex items-center gap-2 hover:bg-zinc-800 transition-all disabled:opacity-50"
          >
            {isSaving ? 'Syncing...' : <><Save className="w-4 h-4" /> Sync All</>}
          </button>
        </div>
      </header>

      {message && (
        <div className={`p-4 rounded-2xl flex items-center gap-3 ${message.type === 'success' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'}`}>
          {message.type === 'success' ? <CheckCircle2 className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          <p className="text-sm font-bold">{message.text}</p>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <aside className="space-y-2">
          <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400 mb-4 px-4">Select Level</p>
          {(['A1', 'A2', 'B1', 'B2', 'C1'] as Level[]).map(level => (
            <button
              key={level}
              onClick={() => setSelectedLevel(level)}
              className={`w-full text-left px-6 py-4 rounded-2xl font-bold transition-all ${
                selectedLevel === level 
                ? 'bg-zinc-900 text-white shadow-lg' 
                : 'bg-white text-zinc-500 hover:bg-zinc-50'
              }`}
            >
              {level}
            </button>
          ))}
        </aside>

        <main className="lg:col-span-3 space-y-6">
          <div className="flex gap-4 p-1 bg-zinc-100 rounded-2xl w-fit">
            <button
              onClick={() => setActiveTab('flashcards')}
              className={`px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === 'flashcards' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
              }`}
            >
              Flashcards
            </button>
            <button
              onClick={() => setActiveTab('quizzes')}
              className={`px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === 'quizzes' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
              }`}
            >
              Quizzes
            </button>
            <button
              onClick={() => setActiveTab('grammar')}
              className={`px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === 'grammar' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
              }`}
            >
              Grammar
            </button>
            <button
              onClick={() => setActiveTab('bulk')}
              className={`px-6 py-2 rounded-xl text-xs font-bold uppercase tracking-widest transition-all ${
                activeTab === 'bulk' ? 'bg-white text-zinc-900 shadow-sm' : 'text-zinc-400 hover:text-zinc-600'
              }`}
            >
              Bulk Upload
            </button>
          </div>

          <div className="bg-white rounded-[32px] p-8 shadow-sm border border-zinc-100">
            {activeTab === 'bulk' ? (
              <div className="space-y-6">
                <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
                  <h2 className="text-2xl font-bold flex items-center gap-2">
                    <Upload className="w-6 h-6" /> Bulk Upload for {selectedLevel}
                  </h2>
                  <div className="flex flex-wrap gap-2 p-1 bg-zinc-50 rounded-xl">
                    <button 
                      onClick={() => setBulkType('flashcards')}
                      className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${bulkType === 'flashcards' ? 'bg-zinc-900 text-white shadow-md' : 'text-zinc-400'}`}
                    >
                      Flashcards
                    </button>
                    <button 
                      onClick={() => setBulkType('vocab-quizzes')}
                      className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${bulkType === 'vocab-quizzes' ? 'bg-zinc-900 text-white shadow-md' : 'text-zinc-400'}`}
                    >
                      Vocab Quizzes
                    </button>
                    <button 
                      onClick={() => setBulkType('grammar-quizzes')}
                      className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${bulkType === 'grammar-quizzes' ? 'bg-zinc-900 text-white shadow-md' : 'text-zinc-400'}`}
                    >
                      Grammar Quizzes
                    </button>
                    <button 
                      onClick={() => setBulkType('grammar-rules')}
                      className={`px-4 py-2 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${bulkType === 'grammar-rules' ? 'bg-zinc-900 text-white shadow-md' : 'text-zinc-400'}`}
                    >
                      Grammar Rules
                    </button>
                  </div>
                </div>
                <p className="text-sm text-zinc-500">
                  Paste a JSON array of {bulkType.replace('-', ' ')} below. 
                  {bulkType.includes('quizzes') ? (
                    <span> Each object should have: <code>question, options (array), correctAnswer, explanation</code>.</span>
                  ) : (
                    <span> Each object should have: <code>german, english, example, wordType</code>.</span>
                  )}
                </p>
                <textarea 
                  value={bulkText}
                  onChange={e => setBulkText(e.target.value)}
                  placeholder={getPlaceholder()}
                  className="w-full h-64 p-6 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900 font-mono text-sm leading-relaxed"
                />
                <div className="flex gap-4">
                  <button 
                    onClick={() => setBulkText('')}
                    className="px-8 py-4 rounded-2xl font-bold uppercase tracking-widest text-xs text-zinc-400 hover:bg-zinc-50"
                  >
                    Clear
                  </button>
                  <button 
                    onClick={handleBulkUpload}
                    disabled={isSaving || !bulkText.trim()}
                    className="flex-1 bg-zinc-900 text-white p-4 rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-zinc-800 disabled:opacity-50 shadow-xl shadow-zinc-900/20"
                  >
                    {isSaving ? 'Processing...' : `Upload ${bulkType}`}
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex flex-col xl:flex-row justify-between items-start xl:items-center gap-6 mb-8">
                  <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 w-full xl:w-auto">
                    <h2 className="text-2xl font-bold flex items-center gap-2 whitespace-nowrap">
                      {activeTab === 'flashcards' && <BookOpen className="w-6 h-6" />}
                      {activeTab === 'quizzes' && <HelpCircle className="w-6 h-6" />}
                      {activeTab === 'grammar' && <GraduationCap className="w-6 h-6" />}
                      {activeTab === 'flashcards' ? 'Flashcards' : activeTab === 'quizzes' ? 'Quizzes' : 'Grammar Rules'} for {selectedLevel}
                    </h2>
                    {activeTab === 'quizzes' && (
                      <div className="flex flex-wrap gap-1 p-1 bg-zinc-50 rounded-xl">
                        {(['all', 'vocabulary', 'grammar'] as const).map(type => (
                          <button 
                            key={type}
                            onClick={() => setQuizFilter(type)}
                            className={`px-3 py-1 rounded-lg text-[10px] font-bold uppercase tracking-widest transition-all ${quizFilter === type ? 'bg-zinc-900 text-white shadow-sm' : 'text-zinc-400 hover:bg-zinc-100'}`}
                          >
                            {type}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                  <div className="flex flex-wrap items-center gap-4 w-full xl:w-auto justify-between xl:justify-end">
                    <button 
                      onClick={handleClearAll}
                      disabled={isSaving}
                      className="flex items-center gap-2 text-rose-500 font-bold text-xs uppercase tracking-widest hover:text-rose-600 disabled:opacity-50"
                    >
                      <Trash2 className="w-4 h-4" /> {isSaving ? 'Processing...' : 'Clear All'}
                    </button>
                    <div className="flex flex-wrap gap-2">
                      {activeTab === 'quizzes' ? (
                        <>
                          <button 
                            onClick={() => setEditingItem({ 
                              type: 'quiz', 
                              data: { id: `new-${Date.now()}`, question: '', options: ['', '', '', ''], correctAnswer: '', explanation: '', level: selectedLevel, type: 'vocabulary' }
                            })}
                            className="flex items-center gap-2 text-indigo-500 font-bold text-xs uppercase tracking-widest hover:text-indigo-600 bg-indigo-50/50 px-3 py-2 rounded-xl"
                          >
                            <Plus className="w-4 h-4" /> Vocab
                          </button>
                          <button 
                            onClick={() => setEditingItem({ 
                              type: 'quiz', 
                              data: { id: `new-${Date.now()}`, question: '', options: ['', '', '', ''], correctAnswer: '', explanation: '', level: selectedLevel, type: 'grammar' }
                            })}
                            className="flex items-center gap-2 text-emerald-500 font-bold text-xs uppercase tracking-widest hover:text-emerald-600 bg-emerald-50/50 px-3 py-2 rounded-xl"
                          >
                            <Plus className="w-4 h-4" /> Grammar
                          </button>
                        </>
                      ) : activeTab === 'grammar' ? (
                        <button 
                          onClick={() => setEditingItem({ 
                            type: 'grammar', 
                            data: { id: `new-${Date.now()}`, title: '', explanation: '', examples: [], level: selectedLevel, category: 'General' }
                          })}
                          className="flex items-center gap-2 text-emerald-500 font-bold text-xs uppercase tracking-widest hover:text-emerald-600 bg-emerald-50/50 px-3 py-2 rounded-xl"
                        >
                          <Plus className="w-4 h-4" /> Add New
                        </button>
                      ) : (
                        <button 
                          onClick={() => setEditingItem({ 
                            type: 'flashcard', 
                            data: { id: `new-${Date.now()}`, german: '', english: '', bangla: '', example: '', type: 'vocabulary', wordType: 'Noun', level: selectedLevel, category: 'General', frequency: undefined }
                          })}
                          className="flex items-center gap-2 text-emerald-500 font-bold text-xs uppercase tracking-widest hover:text-emerald-600 bg-emerald-50/50 px-3 py-2 rounded-xl"
                        >
                          <Plus className="w-4 h-4" /> Add New
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-4">
                  {activeTab === 'flashcards' ? (
                    content[selectedLevel].flashcards.map((card, idx) => (
                      <div key={card.id} className="group flex items-center justify-between p-4 rounded-2xl border border-zinc-50 hover:border-zinc-200 transition-all">
                        <div className="flex items-center gap-4">
                          <span className="text-xs font-bold text-zinc-300 w-6">{idx + 1}</span>
                          <div>
                            <p className="font-bold text-zinc-900">{card.german}</p>
                            <p className="text-xs text-zinc-400">{card.english}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => setEditingItem({ type: 'flashcard', data: { ...card } })}
                            className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-zinc-900"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeleteItem('flashcard', card.id)}
                            className="p-2 hover:bg-rose-50 rounded-lg text-zinc-400 hover:text-rose-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))
                  ) : activeTab === 'quizzes' ? (
                    content[selectedLevel].quizzes
                      .filter(q => quizFilter === 'all' || q.type === quizFilter)
                      .map((quiz, idx) => (
                        <div key={quiz.id} className="group flex items-center justify-between p-4 rounded-2xl border border-zinc-50 hover:border-zinc-200 transition-all">
                          <div className="flex items-center gap-4">
                            <span className="text-xs font-bold text-zinc-300 w-6">{idx + 1}</span>
                            <div>
                              <div className="flex items-center gap-2">
                                <p className="font-bold text-zinc-900">{quiz.question}</p>
                                <span className={`text-[8px] font-bold uppercase tracking-widest px-2 py-0.5 rounded-full ${quiz.type === 'grammar' ? 'bg-emerald-50 text-emerald-600' : 'bg-indigo-50 text-indigo-600'}`}>
                                  {quiz.type}
                                </span>
                              </div>
                              <p className="text-xs text-zinc-400">{quiz.correctAnswer}</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button 
                              onClick={() => setEditingItem({ type: 'quiz', data: { ...quiz } })}
                              className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-zinc-900"
                            >
                              <ChevronRight className="w-4 h-4" />
                            </button>
                            <button 
                              onClick={() => handleDeleteItem('quiz', quiz.id)}
                              className="p-2 hover:bg-rose-50 rounded-lg text-zinc-400 hover:text-rose-500"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </div>
                        </div>
                      ))
                  ) : (
                    (content[selectedLevel].grammarRules || []).map((rule, idx) => (
                      <div key={rule.id} className="group flex items-center justify-between p-4 rounded-2xl border border-zinc-50 hover:border-zinc-200 transition-all">
                        <div className="flex items-center gap-4">
                          <span className="text-xs font-bold text-zinc-300 w-6">{idx + 1}</span>
                          <div>
                            <p className="font-bold text-zinc-900">{rule.title}</p>
                            <p className="text-xs text-zinc-400">{rule.category}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <button 
                            onClick={() => setEditingItem({ type: 'grammar', data: { ...rule } })}
                            className="p-2 hover:bg-zinc-100 rounded-lg text-zinc-400 hover:text-zinc-900"
                          >
                            <ChevronRight className="w-4 h-4" />
                          </button>
                          <button 
                            onClick={() => handleDeleteItem('grammar', rule.id)}
                            className="p-2 hover:bg-rose-50 rounded-lg text-zinc-400 hover:text-rose-500"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </>
            )}
          </div>
        </main>
      </div>

      {editingItem && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[40px] w-full max-w-2xl max-h-[90vh] overflow-y-auto p-12 shadow-2xl"
          >
            <h2 className="text-3xl font-black tracking-tighter mb-8 uppercase">
              Edit {editingItem.type}
            </h2>
            <form onSubmit={handleSaveItem} className="space-y-6">
              {editingItem.type === 'flashcard' ? (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">German</label>
                      <input 
                        type="text" 
                        value={(editingItem.data as Flashcard).german}
                        onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, german: e.target.value } as Flashcard })}
                        className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">English</label>
                      <input 
                        type="text" 
                        value={(editingItem.data as Flashcard).english}
                        onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, english: e.target.value } as Flashcard })}
                        className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Bangla (Optional)</label>
                      <input 
                        type="text" 
                        value={(editingItem.data as Flashcard).bangla || ''}
                        onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, bangla: e.target.value } as Flashcard })}
                        className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Example Sentence</label>
                    <textarea 
                      value={(editingItem.data as Flashcard).example}
                      onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, example: e.target.value } as Flashcard })}
                      className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      rows={3}
                    />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Category</label>
                      <input 
                        type="text" 
                        value={(editingItem.data as Flashcard).category}
                        onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, category: e.target.value } as Flashcard })}
                        className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Word Type</label>
                      <select 
                        value={(editingItem.data as Flashcard).wordType}
                        onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, wordType: e.target.value as WordType } as Flashcard })}
                        className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      >
                        {['Noun', 'Verb', 'Adjective', 'Adverb', 'Phrase', 'Grammar', 'Number'].map(t => (
                          <option key={t} value={t}>{t}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Frequency Rank</label>
                      <input 
                        type="number" 
                        value={(editingItem.data as Flashcard).frequency || ''}
                        onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, frequency: parseInt(e.target.value) || undefined } as Flashcard })}
                        className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                        placeholder="e.g. 1"
                      />
                    </div>
                  </div>
                </>
              ) : editingItem.type === 'quiz' ? (
                <>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Question</label>
                    <input 
                      type="text" 
                      value={(editingItem.data as QuizQuestion).question}
                      onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, question: e.target.value } as QuizQuestion })}
                      className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      required
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    {(editingItem.data as QuizQuestion).options.map((opt: string, i: number) => (
                      <div key={i} className="space-y-2">
                        <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Option {i + 1}</label>
                        <input 
                          type="text" 
                          value={opt}
                          onChange={e => {
                            const newOpts = [...(editingItem.data as QuizQuestion).options];
                            newOpts[i] = e.target.value;
                            setEditingItem({ ...editingItem, data: { ...editingItem.data, options: newOpts } as QuizQuestion });
                          }}
                          className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                          required
                        />
                      </div>
                    ))}
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Correct Answer</label>
                      <select 
                        value={(editingItem.data as QuizQuestion).correctAnswer}
                        onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, correctAnswer: e.target.value } as QuizQuestion })}
                        className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                        required
                      >
                        <option value="">Select Correct Option</option>
                        {(editingItem.data as QuizQuestion).options.map((opt: string, i: number) => (
                          <option key={`${i}-${opt}`} value={opt}>{opt}</option>
                        ))}
                      </select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Type</label>
                      <select 
                        value={(editingItem.data as QuizQuestion).type}
                        onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, type: e.target.value as 'vocabulary' | 'grammar' } as QuizQuestion })}
                        className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      >
                        <option value="vocabulary">Vocabulary</option>
                        <option value="grammar">Grammar</option>
                      </select>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Explanation</label>
                    <textarea 
                      value={(editingItem.data as QuizQuestion).explanation}
                      onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, explanation: e.target.value } as QuizQuestion })}
                      className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      rows={2}
                    />
                  </div>
                </>
              ) : (
                <>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Title</label>
                    <input 
                      type="text" 
                      value={(editingItem.data as GrammarRule).title}
                      onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, title: e.target.value } as GrammarRule })}
                      className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Explanation (Markdown)</label>
                      <span className="text-[10px] text-zinc-400 italic">Line breaks are preserved</span>
                    </div>
                    <textarea 
                      value={(editingItem.data as GrammarRule).explanation}
                      onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, explanation: e.target.value } as GrammarRule })}
                      className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                      rows={10}
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Category</label>
                    <input 
                      type="text" 
                      value={(editingItem.data as GrammarRule).category}
                      onChange={e => setEditingItem({ ...editingItem, data: { ...editingItem.data, category: e.target.value } as GrammarRule })}
                      className="w-full p-4 rounded-2xl bg-zinc-50 border-none focus:ring-2 focus:ring-zinc-900"
                    />
                  </div>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <label className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">Examples</label>
                      <button 
                        type="button"
                        onClick={() => {
                          const newExamples = [...(editingItem.data as GrammarRule).examples, { german: '', english: '' }];
                          setEditingItem({ ...editingItem, data: { ...editingItem.data, examples: newExamples } as GrammarRule });
                        }}
                        className="text-xs font-bold text-zinc-900 flex items-center gap-1"
                      >
                        <Plus className="w-3 h-3" /> Add Example
                      </button>
                    </div>
                    {(editingItem.data as GrammarRule).examples.map((ex, i) => (
                      <div key={i} className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-zinc-50 rounded-2xl relative group">
                        <div className="space-y-1">
                          <label className="text-[8px] font-bold uppercase tracking-widest text-zinc-400">German</label>
                          <input 
                            type="text" 
                            value={ex.german}
                            onChange={e => {
                              const newExs = [...(editingItem.data as GrammarRule).examples];
                              newExs[i].german = e.target.value;
                              setEditingItem({ ...editingItem, data: { ...editingItem.data, examples: newExs } as GrammarRule });
                            }}
                            className="w-full p-2 rounded-xl bg-white border-none focus:ring-1 focus:ring-zinc-900 text-sm"
                          />
                        </div>
                        <div className="space-y-1">
                          <label className="text-[8px] font-bold uppercase tracking-widest text-zinc-400">English</label>
                          <input 
                            type="text" 
                            value={ex.english}
                            onChange={e => {
                              const newExs = [...(editingItem.data as GrammarRule).examples];
                              newExs[i].english = e.target.value;
                              setEditingItem({ ...editingItem, data: { ...editingItem.data, examples: newExs } as GrammarRule });
                            }}
                            className="w-full p-2 rounded-xl bg-white border-none focus:ring-1 focus:ring-zinc-900 text-sm"
                          />
                        </div>
                        <button 
                          type="button"
                          onClick={() => {
                            const newExs = (editingItem.data as GrammarRule).examples.filter((_, idx) => idx !== i);
                            setEditingItem({ ...editingItem, data: { ...editingItem.data, examples: newExs } as GrammarRule });
                          }}
                          className="absolute -top-2 -right-2 bg-white text-rose-500 p-1 rounded-full shadow-sm border border-zinc-100 opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </>
              )}

              <div className="flex gap-4 pt-4">
                <button 
                  type="button"
                  onClick={() => setEditingItem(null)}
                  className="flex-1 p-4 rounded-2xl font-bold uppercase tracking-widest text-xs text-zinc-400 hover:bg-zinc-50"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  disabled={isSaving}
                  className="flex-1 bg-zinc-900 text-white p-4 rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-zinc-800 disabled:opacity-50"
                >
                  {isSaving ? 'Saving...' : 'Save Changes'}
                </button>
              </div>
            </form>
          </motion.div>
        </div>
      )}

      {confirmModal.isOpen && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-[110] flex items-center justify-center p-6">
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-[40px] w-full max-w-md p-10 shadow-2xl text-center"
          >
            <div className="bg-rose-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <AlertCircle className="w-8 h-8 text-rose-500" />
            </div>
            <h3 className="text-2xl font-black tracking-tighter uppercase mb-2">{confirmModal.title}</h3>
            <p className="text-zinc-500 mb-8">{confirmModal.message}</p>
            <div className="flex gap-4">
              <button 
                onClick={() => setConfirmModal(prev => ({ ...prev, isOpen: false }))}
                className="flex-1 p-4 rounded-2xl font-bold uppercase tracking-widest text-xs text-zinc-400 hover:bg-zinc-50"
              >
                Cancel
              </button>
              <button 
                onClick={confirmModal.onConfirm}
                disabled={isSaving}
                className="flex-1 bg-rose-500 text-white p-4 rounded-2xl font-bold uppercase tracking-widest text-xs hover:bg-rose-600 disabled:opacity-50 shadow-xl shadow-rose-500/20"
              >
                {isSaving ? 'Deleting...' : 'Confirm Delete'}
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
};
