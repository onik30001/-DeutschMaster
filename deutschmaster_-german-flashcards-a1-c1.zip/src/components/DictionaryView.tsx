import React, { useState, useMemo } from 'react';
import { Flashcard } from '../types';
import { 
  Search, 
  Eye, 
  EyeOff, 
  CheckCircle2, 
  ChevronLeft, 
  ChevronRight, 
  Volume2, 
  Star,
  MoreHorizontal
} from 'lucide-react';

interface Props {
  flashcards: Flashcard[];
  favorites: string[];
  onToggleFavorite: (id: string) => void;
  onSpeak: (text: string) => void;
}

export const DictionaryView: React.FC<Props> = ({ 
  flashcards, 
  favorites, 
  onToggleFavorite,
  onSpeak
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [hideAllTranslations, setHideAllTranslations] = useState(false);
  const [revealedIds, setRevealedIds] = useState<Set<string>>(new Set());
  const itemsPerPage = 20;

  const filteredCards = useMemo(() => {
    return flashcards.filter(card => 
      card.german.toLowerCase().includes(searchTerm.toLowerCase()) ||
      card.english.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (card.bangla && card.bangla.toLowerCase().includes(searchTerm.toLowerCase()))
    ).sort((a, b) => (a.frequency || 9999) - (b.frequency || 9999));
  }, [flashcards, searchTerm]);

  const totalPages = Math.ceil(filteredCards.length / itemsPerPage);
  const currentItems = filteredCards.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const toggleReveal = (id: string) => {
    const newRevealed = new Set(revealedIds);
    if (newRevealed.has(id)) {
      newRevealed.delete(id);
    } else {
      newRevealed.add(id);
    }
    setRevealedIds(newRevealed);
  };

  return (
    <div className="space-y-8">
      {/* Controls */}
      <div className="flex flex-col md:flex-row gap-6 justify-between items-center">
        <div className="relative w-full md:w-96 group">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-400 group-focus-within:text-zinc-900 transition-colors" />
          <input 
            type="text"
            placeholder="Search dictionary..."
            value={searchTerm}
            onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
            className="w-full pl-14 pr-6 py-4 rounded-2xl bg-white border border-zinc-100 shadow-sm focus:ring-2 focus:ring-zinc-900 transition-all font-medium"
          />
        </div>

        <div className="flex items-center gap-4">
          <button 
            onClick={() => setHideAllTranslations(!hideAllTranslations)}
            className={`flex items-center gap-3 px-6 py-4 rounded-2xl font-bold uppercase tracking-widest text-[10px] transition-all ${hideAllTranslations ? 'bg-zinc-900 text-white shadow-xl' : 'bg-white text-zinc-500 border border-zinc-100 hover:bg-zinc-50'}`}
          >
            {hideAllTranslations ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            {hideAllTranslations ? 'Translations Hidden' : 'Hide Translations'}
          </button>
        </div>
      </div>

      {/* Table */}
      <div className="bg-white rounded-[40px] border border-zinc-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-bottom border-zinc-50">
                <th className="px-8 py-6 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400">Freq</th>
                <th className="px-8 py-6 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400">Word</th>
                <th className="px-8 py-6 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400">English</th>
                <th className="px-8 py-6 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400">Bangla</th>
                <th className="px-8 py-6 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400">Type</th>
                <th className="px-8 py-6 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400 text-center">Learned</th>
                <th className="px-8 py-6 text-[10px] font-bold uppercase tracking-[0.2em] text-zinc-400 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-zinc-50">
              {currentItems.map((card) => {
                const isLearned = favorites.includes(card.id);
                const isRevealed = revealedIds.has(card.id);
                const showTranslation = !hideAllTranslations || isRevealed;

                return (
                  <tr key={card.id} className="group hover:bg-zinc-50/50 transition-colors">
                    <td className="px-8 py-6">
                      <span className="font-mono text-xs text-zinc-400">#{card.frequency || '-'}</span>
                    </td>
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-3">
                        <span className="text-lg font-bold text-zinc-900">{card.german}</span>
                        <button 
                          onClick={() => onSpeak(card.german)}
                          className="p-1.5 text-zinc-300 hover:text-zinc-900 transition-colors"
                        >
                          <Volume2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div 
                        onClick={() => toggleReveal(card.id)}
                        className={`cursor-pointer transition-all duration-300 ${showTranslation ? 'opacity-100 blur-0' : 'opacity-20 blur-md select-none'}`}
                      >
                        <span className="text-zinc-600 font-medium">{card.english}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <div 
                        onClick={() => toggleReveal(card.id)}
                        className={`cursor-pointer transition-all duration-300 ${showTranslation ? 'opacity-100 blur-0' : 'opacity-20 blur-md select-none'}`}
                      >
                        <span className="text-zinc-600 font-medium">{card.bangla || '-'}</span>
                      </div>
                    </td>
                    <td className="px-8 py-6">
                      <span className="px-3 py-1 bg-zinc-100 rounded-full text-[10px] font-bold uppercase tracking-widest text-zinc-500">
                        {card.wordType}
                      </span>
                    </td>
                    <td className="px-8 py-6 text-center">
                      <button 
                        onClick={() => onToggleFavorite(card.id)}
                        className={`transition-all duration-300 ${isLearned ? 'text-emerald-500 scale-110' : 'text-zinc-200 hover:text-zinc-400'}`}
                      >
                        <CheckCircle2 className="w-6 h-6" />
                      </button>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex justify-end gap-2">
                        <button 
                          onClick={() => onToggleFavorite(card.id)}
                          className={`p-2 rounded-xl transition-all ${favorites.includes(card.id) ? 'bg-rose-50 text-rose-500' : 'text-zinc-300 hover:bg-zinc-100 hover:text-zinc-600'}`}
                        >
                          <Star className={`w-4 h-4 ${favorites.includes(card.id) ? 'fill-current' : ''}`} />
                        </button>
                        <button className="p-2 text-zinc-300 hover:bg-zinc-100 hover:text-zinc-600 rounded-xl transition-all">
                          <MoreHorizontal className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Empty State */}
        {filteredCards.length === 0 && (
          <div className="p-20 text-center space-y-4">
            <div className="bg-zinc-50 w-20 h-20 rounded-full flex items-center justify-center mx-auto">
              <Search className="w-8 h-8 text-zinc-200" />
            </div>
            <h3 className="text-xl font-bold text-zinc-900">No words found</h3>
            <p className="text-zinc-400 text-sm">Try adjusting your search terms.</p>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="px-8 py-6 border-t border-zinc-50 flex flex-col sm:flex-row justify-between items-center gap-4">
            <p className="text-[10px] font-bold uppercase tracking-widest text-zinc-400">
              Page {currentPage} of {totalPages}
            </p>
            <div className="flex items-center gap-2">
              <button 
                disabled={currentPage === 1}
                onClick={() => setCurrentPage(prev => prev - 1)}
                className="p-2 rounded-xl border border-zinc-100 disabled:opacity-30 hover:bg-zinc-50 transition-all"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              
              <div className="flex items-center gap-1">
                {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                  let pageNum;
                  if (totalPages <= 5) pageNum = i + 1;
                  else if (currentPage <= 3) pageNum = i + 1;
                  else if (currentPage >= totalPages - 2) pageNum = totalPages - 4 + i;
                  else pageNum = currentPage - 2 + i;

                  return (
                    <button
                      key={pageNum}
                      onClick={() => setCurrentPage(pageNum)}
                      className={`w-10 h-10 rounded-xl text-xs font-bold transition-all ${currentPage === pageNum ? 'bg-zinc-900 text-white shadow-lg' : 'hover:bg-zinc-50 text-zinc-400'}`}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>

              <button 
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage(prev => prev + 1)}
                className="p-2 rounded-xl border border-zinc-100 disabled:opacity-30 hover:bg-zinc-50 transition-all"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
