import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Flashcard } from '../types';
import { Volume2, Bookmark, Heart, ChevronRight, ChevronLeft, Loader2 } from 'lucide-react';
import { generateSpeech, playAudio } from '../services/gemini';

interface Props {
  card: Flashcard;
  onNext: () => void;
  onPrev: () => void;
  isFavorite: boolean;
  isBookmarked: boolean;
  onToggleFavorite: () => void;
  onToggleBookmark: () => void;
}

export const FlashcardComponent: React.FC<Props> = ({ 
  card, 
  onNext, 
  onPrev, 
  isFavorite, 
  isBookmarked,
  onToggleFavorite,
  onToggleBookmark
}) => {
  const [isFlipped, setIsFlipped] = useState(false);
  const [isAudioLoading, setIsAudioLoading] = useState(false);

  // Reset flip state when card changes
  useEffect(() => {
    setIsFlipped(false);
  }, [card.id]);

  const handleSpeak = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setIsAudioLoading(true);

    try {
      const audioData = await generateSpeech(card.german);
      if (audioData) {
        playAudio(audioData.data, audioData.mimeType || 'audio/mpeg');
      } else {
        // Fallback to browser TTS if Gemini fails
        window.speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(card.german);
        utterance.lang = 'de-DE';
        window.speechSynthesis.speak(utterance);
      }
    } catch (error) {
      console.error("Audio Error:", error);
      // Fallback
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(card.german);
      utterance.lang = 'de-DE';
      window.speechSynthesis.speak(utterance);
    } finally {
      setIsAudioLoading(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-12">
      <div className="relative h-[480px] w-full perspective-2000 group">
        <motion.div
          className="w-full h-full relative preserve-3d cursor-pointer"
          animate={{ rotateY: isFlipped ? 180 : 0 }}
          transition={{ duration: 0.8, type: 'spring', stiffness: 200, damping: 25 }}
          onClick={() => setIsFlipped(!isFlipped)}
        >
          {/* Front */}
          <div className="absolute inset-0 backface-hidden bg-white rounded-[64px] p-16 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.1)] flex flex-col items-center justify-center text-center border border-zinc-100/50 overflow-hidden">
            <div className="absolute top-12 right-12 flex gap-3">
              <button 
                onClick={(e) => { e.stopPropagation(); onToggleBookmark(); }}
                className={`p-3.5 rounded-2xl transition-all duration-300 ${isBookmarked ? 'bg-zinc-900 text-white shadow-xl' : 'bg-zinc-50 text-zinc-400 hover:bg-zinc-100'}`}
              >
                <Bookmark className="w-5 h-5" />
              </button>
              <button 
                onClick={(e) => { e.stopPropagation(); onToggleFavorite(); }}
                className={`p-3.5 rounded-2xl transition-all duration-300 ${isFavorite ? 'bg-rose-500 text-white shadow-xl' : 'bg-zinc-50 text-zinc-400 hover:bg-zinc-100'}`}
              >
                <Heart className={`w-5 h-5 ${isFavorite ? 'fill-current' : ''}`} />
              </button>
            </div>
            
            <div className="space-y-10">
              <span className="bg-zinc-100 px-5 py-2 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-500 inline-block">{card.wordType}</span>
              <h2 className="text-6xl font-bold tracking-tight text-zinc-900">{card.german}</h2>
              <div className="flex flex-col items-center gap-6">
                <button 
                  onClick={handleSpeak}
                  disabled={isAudioLoading}
                  className="p-5 bg-zinc-900 text-white rounded-[32px] hover:scale-110 active:scale-95 transition-all shadow-2xl shadow-zinc-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isAudioLoading ? (
                    <Loader2 className="w-8 h-8 animate-spin" />
                  ) : (
                    <Volume2 className="w-8 h-8" />
                  )}
                </button>
                <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-zinc-300 animate-pulse">Click to reveal meaning</p>
              </div>
            </div>
            <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-zinc-50 rounded-full blur-3xl opacity-50 pointer-events-none" />
          </div>

          {/* Back */}
          <div className="absolute inset-0 backface-hidden bg-zinc-900 rounded-[64px] p-16 shadow-[0_40px_100px_-20px_rgba(0,0,0,0.3)] flex flex-col items-center justify-center text-center rotate-y-180 overflow-hidden">
            <div className="space-y-10 relative z-10 w-full">
              <span className="bg-white/10 px-5 py-2 rounded-full text-[10px] font-bold uppercase tracking-[0.3em] text-zinc-500 inline-block backdrop-blur-md">Translation</span>
              <div className="space-y-2">
                <h2 className="text-5xl font-bold tracking-tight text-white">{card.english}</h2>
                {card.bangla && (
                  <p className="text-2xl font-medium text-zinc-400">{card.bangla}</p>
                )}
              </div>
              <div className="bg-white/5 rounded-[40px] p-10 w-full border border-white/5 backdrop-blur-xl relative group/example">
                <p className="text-zinc-400 text-lg font-medium leading-relaxed">"{card.example}"</p>
                <button 
                  onClick={async (e) => {
                    e.stopPropagation();
                    setIsAudioLoading(true);
                    try {
                      const audioData = await generateSpeech(card.example);
                      if (audioData) playAudio(audioData.data, audioData.mimeType || 'audio/mpeg');
                    } finally {
                      setIsAudioLoading(false);
                    }
                  }}
                  disabled={isAudioLoading}
                  className="absolute -right-4 -top-4 p-3 bg-white text-zinc-900 rounded-2xl shadow-xl opacity-0 group-hover/example:opacity-100 transition-all hover:scale-110 active:scale-95 disabled:opacity-50"
                >
                  {isAudioLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Volume2 className="w-4 h-4" />}
                </button>
              </div>
              <p className="text-[10px] font-bold uppercase tracking-[0.4em] text-zinc-600">Click to flip back</p>
            </div>
            <div className="absolute -top-24 -right-24 w-96 h-96 bg-white/5 rounded-full blur-3xl opacity-50 pointer-events-none" />
            <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-indigo-500/10 rounded-full blur-3xl opacity-50 pointer-events-none" />
          </div>
        </motion.div>
      </div>

      <div className="flex items-center justify-between px-8">
        <button 
          onClick={onPrev} 
          className="p-6 bg-white rounded-[32px] shadow-xl hover:bg-zinc-50 transition-all text-zinc-400 hover:text-zinc-900 border border-zinc-100/50 group"
        >
          <ChevronLeft className="w-8 h-8 group-hover:-translate-x-1 transition-transform" />
        </button>
        <div className="flex gap-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className={`h-2 rounded-full transition-all duration-500 ${i === 0 ? 'w-12 bg-zinc-900' : 'w-2 bg-zinc-200'}`} />
          ))}
        </div>
        <button 
          onClick={onNext} 
          className="p-6 bg-white rounded-[32px] shadow-xl hover:bg-zinc-50 transition-all text-zinc-400 hover:text-zinc-900 border border-zinc-100/50 group"
        >
          <ChevronRight className="w-8 h-8 group-hover:translate-x-1 transition-transform" />
        </button>
      </div>
    </div>
  );
};
