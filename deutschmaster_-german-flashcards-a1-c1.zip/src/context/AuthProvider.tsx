import { useEffect, useState } from 'react';
import { auth, db, onAuthStateChanged, doc, getDoc, setDoc, handleFirestoreError, OperationType, serverTimestamp } from '../firebase';
import { UserProgress, Level } from '../types';
import { AuthContext, AuthContextType } from './AuthContext';
import { User } from 'firebase/auth';

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [progress, setProgress] = useState<UserProgress | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    return onAuthStateChanged(auth, async (user) => {
      setUser(user as User | null);
      if (user) {
        console.log("Auth state changed: User logged in", user.uid, user.email);
        const docRef = doc(db, 'users', user.uid);
        try {
          console.log("Fetching user document...");
          const docSnap = await getDoc(docRef);
          
          if (docSnap.exists()) {
            console.log("User document found");
            const data = docSnap.data() as UserProgress;
            // Ensure admin role is synced if email matches
            if (user.email === 'onik30001@gmail.com' && data.role !== 'admin') {
              console.log("Syncing admin role for", user.email);
              const updatedData = { ...data, role: 'admin' as const };
              await setDoc(docRef, { role: 'admin' }, { merge: true });
              setProgress(updatedData);
            } else {
              setProgress(data);
            }
          } else {
            console.log("User document not found, creating initial progress...");
            const initialProgress: UserProgress = {
              uid: user.uid,
              email: user.email || '',
              level: 'A1',
              xp: 0,
              streak: 0,
              lastActive: serverTimestamp(),
              createdAt: serverTimestamp(),
              purchasedLevels: [],
              favorites: [],
              bookmarks: [],
              role: user.email === 'onik30001@gmail.com' ? 'admin' : 'user'
            };
            await setDoc(docRef, initialProgress);
            console.log("Initial progress created");
            setProgress({ ...initialProgress, lastActive: new Date(), createdAt: new Date() });
          }
        } catch (error) {
          console.error("Error in AuthProvider:", error);
          handleFirestoreError(error, OperationType.GET, `users/${user.uid}`);
        }
      } else {
        setProgress(null);
      }
      setLoading(false);
    });
  }, []);

  const updateProgress = async (updates: Partial<UserProgress>) => {
    if (!user) return;
    const docRef = doc(db, 'users', user.uid);
    try {
      const finalUpdates = { ...updates, lastActive: serverTimestamp() };
      await setDoc(docRef, finalUpdates, { merge: true });
      setProgress(prev => prev ? { ...prev, ...updates, lastActive: new Date() } : null);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
    }
  };

  const hasAccess = (level: Level) => {
    if (!progress) return false;
    if (progress.role === 'admin') return true;
    
    if (progress.purchasedLevels?.includes(level)) return true;
    
    if (level === 'A1') {
      let createdAtDate: Date;
      if (progress.createdAt instanceof Date) {
        createdAtDate = progress.createdAt;
      } else if (typeof (progress.createdAt as { toDate?: () => Date })?.toDate === 'function') {
        createdAtDate = (progress.createdAt as { toDate: () => Date }).toDate();
      } else if ((progress.createdAt as { seconds: number })?.seconds) {
        createdAtDate = new Date((progress.createdAt as { seconds: number }).seconds * 1000);
      } else {
        createdAtDate = new Date();
      }
      
      const trialMs = 3 * 24 * 60 * 60 * 1000;
      return (new Date().getTime() - createdAtDate.getTime()) < trialMs;
    }
    
    return false;
  };

  const value: AuthContextType = {
    user: user as User | null,
    progress,
    loading,
    updateProgress,
    hasAccess
  };

  return (
    <AuthContext.Provider value={value}>
      {children}
    </AuthContext.Provider>
  );
};
