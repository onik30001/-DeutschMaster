import { createContext, useContext } from 'react';
import { SiteContent } from '../types';

export interface ContentContextType {
  content: SiteContent;
  loading: boolean;
}

export const ContentContext = createContext<ContentContextType | undefined>(undefined);

export const useContent = () => {
  const context = useContext(ContentContext);
  if (context === undefined) {
    throw new Error('useContent must be used within a ContentProvider');
  }
  return context;
};
