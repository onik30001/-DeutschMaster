import { createContext, useContext } from 'react';
import { User } from '../firebase';
import { UserProgress, Level } from '../types';

export interface AuthContextType {
  user: User | null;
  progress: UserProgress | null;
  loading: boolean;
  updateProgress: (updates: Partial<UserProgress>) => Promise<void>;
  hasAccess: (level: Level) => boolean;
}

export const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
