import { useEffect, useState } from 'react';
import { db, collection, onSnapshot, handleFirestoreError, OperationType } from '../firebase';
import { SiteContent, Level } from '../types';
import { useAuth } from './AuthContext';
import { ContentContext, ContentContextType } from './ContentContext';

const INITIAL_CONTENT: SiteContent = {
  A1: { flashcards: [], quizzes: [], grammarRules: [] },
  A2: { flashcards: [], quizzes: [], grammarRules: [] },
  B1: { flashcards: [], quizzes: [], grammarRules: [] },
  B2: { flashcards: [], quizzes: [], grammarRules: [] },
  C1: { flashcards: [], quizzes: [], grammarRules: [] },
};

export const ContentProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user, loading: authLoading } = useAuth();
  const [content, setContent] = useState<SiteContent>(INITIAL_CONTENT);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (authLoading) return;

    if (!user) {
      const timer = setTimeout(() => setLoading(false), 0);
      return () => clearTimeout(timer);
    }

    const unsubscribe = onSnapshot(collection(db, 'content'), (snapshot) => {
      const newContent = { ...INITIAL_CONTENT };
      snapshot.forEach((doc) => {
        const level = doc.id as Level;
        if (newContent[level]) {
          const data = doc.data();
          newContent[level] = {
            flashcards: Array.isArray(data.flashcards) ? data.flashcards : [],
            quizzes: Array.isArray(data.quizzes) ? data.quizzes : [],
            grammarRules: Array.isArray(data.grammarRules) ? data.grammarRules : []
          };
        }
      });
      setContent(newContent);
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'content');
      setLoading(false);
    });

    return () => unsubscribe();
  }, [user, authLoading]);

  const value: ContentContextType = {
    content,
    loading
  };

  return (
    <ContentContext.Provider value={value}>
      {children}
    </ContentContext.Provider>
  );
};
