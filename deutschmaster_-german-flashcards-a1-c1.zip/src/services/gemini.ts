import { GoogleGenAI } from "@google/genai";

// Initialize the Gemini API
const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

/**
 * Generates high-quality speech using Gemini TTS
 * @param text The German text to speak
 * @returns Object containing base64 data and mimeType
 */
export const generateSpeech = async (text: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: `Say clearly in German: ${text}` }] }],
      config: {
        responseModalities: ["AUDIO"],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: 'Kore' },
          },
        },
      },
    });

    const inlineData = response.candidates?.[0]?.content?.parts?.[0]?.inlineData;
    if (inlineData && inlineData.data) {
      return {
        data: inlineData.data,
        mimeType: inlineData.mimeType || 'audio/mpeg'
      };
    }
    return null;
  } catch (error) {
    console.error("Gemini TTS Error:", error);
    return null;
  }
};

/**
 * Plays audio from a base64 string
 * @param base64Data Base64 encoded audio data
 * @param mimeType The MIME type of the audio data
 */
export const playAudio = async (base64Data: string, mimeType: string = 'audio/mpeg') => {
  // If it's PCM data (common for Gemini TTS), use Web Audio API for playback
  if (mimeType.includes('pcm') || mimeType.includes('L16')) {
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const audioContext = new AudioContextClass({ sampleRate: 24000 });
      
      // Decode base64 to ArrayBuffer
      const binaryString = atob(base64Data);
      const bytes = new Uint8Array(binaryString.length);
      for (let i = 0; i < binaryString.length; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }
      
      // Gemini returns 16-bit linear PCM (Int16)
      const int16Array = new Int16Array(bytes.buffer);
      const float32Array = new Float32Array(int16Array.length);
      
      // Normalize Int16 to Float32 (-1.0 to 1.0)
      for (let i = 0; i < int16Array.length; i++) {
        float32Array[i] = int16Array[i] / 32768.0;
      }
      
      const audioBuffer = audioContext.createBuffer(1, float32Array.length, 24000);
      audioBuffer.getChannelData(0).set(float32Array);
      
      const source = audioContext.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioContext.destination);
      source.start();
    } catch (err) {
      console.error("PCM Playback Error:", err);
      // Fallback to standard Audio element if Web Audio fails
      const audioSrc = `data:${mimeType};base64,${base64Data}`;
      const audio = new Audio(audioSrc);
      audio.play().catch(e => console.error("Fallback Audio Error:", e));
    }
  } else {
    // Standard playback for supported formats like mpeg, wav, etc.
    const audioSrc = `data:${mimeType};base64,${base64Data}`;
    const audio = new Audio(audioSrc);
    audio.play().catch(err => {
      console.error("Audio Playback Error:", err);
      console.log("MIME Type used:", mimeType);
    });
  }
};
