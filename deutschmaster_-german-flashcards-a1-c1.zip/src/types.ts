import { Timestamp, FieldValue } from 'firebase/firestore';

export type Level = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';

export type WordType = 'Noun' | 'Verb' | 'Adjective' | 'Adverb' | 'Phrase' | 'Grammar' | 'Number' | 'Any';

export interface Flashcard {
  id: string;
  german: string;
  english: string;
  bangla?: string;
  example: string;
  type: 'vocabulary' | 'grammar';
  wordType: WordType;
  level: Level;
  category: string;
  frequency?: number;
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: string;
  explanation: string;
  level: Level;
  type: 'vocabulary' | 'grammar';
}

export interface GrammarRule {
  id: string;
  title: string;
  explanation: string;
  examples: { german: string; english: string }[];
  level: Level;
  category: string;
}

export interface UserProgress {
  uid: string;
  email: string;
  level: Level;
  xp: number;
  streak: number;
  lastActive: Timestamp | FieldValue | { seconds: number; nanoseconds: number } | Date | null;
  favorites: string[];
  bookmarks: string[];
  role: 'user' | 'admin';
  createdAt: Timestamp | FieldValue | { seconds: number; nanoseconds: number } | Date;
  purchasedLevels: Level[];
  quizScores?: {
    vocabulary: number;
    grammar: number;
    totalAttempts: number;
  };
}

export interface LevelContent {
  flashcards: Flashcard[];
  quizzes: QuizQuestion[];
  grammarRules: GrammarRule[];
}

export type SiteContent = Record<Level, LevelContent>;
